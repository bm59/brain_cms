-- phpMyAdmin SQL Dump
-- version 3.3.10
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Июл 12 2015 г., 21:02
-- Версия сервера: 5.5.11
-- Версия PHP: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `brain_cms`
--

-- --------------------------------------------------------

--
-- Структура таблицы `pr_banners_clicks`
--

CREATE TABLE IF NOT EXISTS `pr_banners_clicks` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `section_id` bigint(20) NOT NULL,
  `banner_id` bigint(20) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `num` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`banner_id`),
  KEY `date` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `pr_banners_clicks`
--


-- --------------------------------------------------------

--
-- Структура таблицы `pr_banners_shows`
--

CREATE TABLE IF NOT EXISTS `pr_banners_shows` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `section_id` bigint(20) NOT NULL,
  `banner_id` bigint(20) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `num` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`banner_id`),
  KEY `date` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `pr_banners_shows`
--


-- --------------------------------------------------------

--
-- Структура таблицы `site_bk_users_info`
--

CREATE TABLE IF NOT EXISTS `site_bk_users_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `regdate` date DEFAULT NULL,
  `login` varchar(255) DEFAULT NULL,
  `pswd` varchar(255) DEFAULT NULL,
  `type` bigint(20) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `secondname` varchar(255) DEFAULT NULL,
  `parentname` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `picture` bigint(20) DEFAULT NULL,
  `settings` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `site_bk_users_info`
--

INSERT INTO `site_bk_users_info` (`id`, `regdate`, `login`, `pswd`, `type`, `firstname`, `secondname`, `parentname`, `email`, `picture`, `settings`) VALUES
(1, '2011-05-25', 'admin', '039a8f73e1e5dcf7663d4ef8db24ece4', 1, 'admin', 'admin', 'admin', '', 0, '|engage|notypechange|norename|nologinchange|undeletable|noswitch|help=users_mainadmin|lasttime=1436720495|'),
(2, '2015-06-23', 'director', '3d4e992d8d8a7d848724aa26ed7f4176', 2, 'director', 'director', 'director', '', 0, '|lasttime=1435255790|engage|'),
(3, '2015-06-25', 'user', 'ee11cbb19052e40b07aac0ca060c23ee', 3, 'user', 'user', 'user', '', 0, '|engage|lasttime=1436707289|');

-- --------------------------------------------------------

--
-- Структура таблицы `site_bk_users_types`
--

CREATE TABLE IF NOT EXISTS `site_bk_users_types` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `access` text,
  `settings` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `site_bk_users_types`
--

INSERT INTO `site_bk_users_types` (`id`, `name`, `access`, `settings`) VALUES
(1, 'Разработчики', '', '|undeletable|superaccess|noedit|help=usergroups_admins|'),
(2, 'Администраторы', '|3=|5=view|4=onoff,view,edit|1=|2=view,add,edit,delete|14=|6=|7=|18=|21=|', NULL),
(3, 'Пользователи', '|6=|7=|8=|9=|10=|11=|13=|', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `site_log`
--

CREATE TABLE IF NOT EXISTS `site_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `item_id` bigint(20) NOT NULL,
  `descr` varchar(255) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `changes` text,
  `user_name` varchar(255) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_num` (`item_id`),
  KEY `descr` (`descr`),
  KEY `date` (`date`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=133 ;

--
-- Дамп данных таблицы `site_log`
--

INSERT INTO `site_log` (`id`, `date`, `item_id`, `descr`, `comment`, `user_id`, `changes`, `user_name`, `ip`) VALUES
(84, '2015-06-25 23:10:04', 2, 'выход из кабинета', '', 2, '', 'director', '127.0.0.1'),
(82, '2015-06-25 23:09:42', 1, 'выход из кабинета', '', 1, '', 'admin', '127.0.0.1'),
(83, '2015-06-25 23:09:50', 2, 'успешная авторизация', '', 2, '', 'director', '127.0.0.1'),
(81, '2015-06-25 23:09:31', 2, 'редактирование группы', 'Администраторы', 1, '', 'admin', '127.0.0.1'),
(80, '2015-06-25 23:09:12', 5, 'редактирование настройки', 'log_enable|0|1', 1, '', 'admin', '127.0.0.1'),
(79, '2015-06-25 23:08:56', 21, 'редактирование свойств раздела', 'Страница', 1, '', 'admin', '127.0.0.1'),
(78, '2015-06-25 23:08:54', 21, 'редактирование свойств раздела', 'Страница', 1, '', 'admin', '127.0.0.1'),
(77, '2015-06-25 23:08:40', 21, 'перенос раздела: добавть к', '21|6', 1, '', 'admin', '127.0.0.1'),
(76, '2015-06-25 23:08:37', 0, 'добавление раздела', 'Страница', 1, '', 'admin', '127.0.0.1'),
(75, '2015-06-25 23:08:22', 15, 'удаление раздела', 'Новый разд', 1, '', 'admin', '127.0.0.1'),
(74, '2015-06-25 23:08:17', 9, 'удаление раздела', 'Заказать сайт', 1, '', 'admin', '127.0.0.1'),
(73, '2015-06-25 23:08:01', 19, 'удаление раздела', '1', 1, '', 'admin', '127.0.0.1'),
(72, '2015-06-25 23:04:57', 17, 'удаление раздела', '55555', 1, '', 'admin', '127.0.0.1'),
(71, '2015-06-25 22:57:44', 20, 'удаление раздела', '1', 1, '', 'admin', '127.0.0.1'),
(70, '2015-06-25 22:57:38', 6, 'редактирование свойств раздела', 'Содержимое сайта', 1, '', 'admin', '127.0.0.1'),
(69, '2015-06-25 21:08:25', 20, 'перенос раздела: добавть к', '20|6', 1, '', 'admin', '127.0.0.1'),
(68, '2015-06-25 21:08:20', 19, 'перенос раздела: добавть к', '19|6', 1, '', 'admin', '127.0.0.1'),
(67, '2015-06-25 21:08:14', 0, 'добавление раздела', '1', 1, '', 'admin', '127.0.0.1'),
(66, '2015-06-25 19:20:21', 0, 'добавление раздела', '1', 1, '', 'admin', '127.0.0.1'),
(65, '2015-06-25 19:20:08', 10, 'удаление раздела', 'Портфолио', 1, '', 'admin', '127.0.0.1'),
(63, '2015-06-25 18:41:49', 18, 'перенос раздела: добавть к', '18|6', 1, '', 'admin', '127.0.0.1'),
(64, '2015-06-25 19:01:50', 18, 'перенос раздела: добавть к', '18|6', 1, '', 'admin', '127.0.0.1'),
(62, '2015-06-25 18:41:46', 0, 'добавление раздела', 'Тестовый', 1, '', 'admin', '127.0.0.1'),
(59, '2015-06-25 18:32:33', 8, 'перенос раздела: добавть к', '8|9', 1, '', 'admin', '127.0.0.1'),
(60, '2015-06-25 18:32:37', 8, 'перенос раздела: добавть к', '8|7', 1, '', 'admin', '127.0.0.1'),
(61, '2015-06-25 18:32:54', 8, 'удаление раздела', 'Цены', 1, '', 'admin', '127.0.0.1'),
(58, '2015-06-25 18:32:29', 8, 'перенос раздела: добавть к', '8|9', 1, '', 'admin', '127.0.0.1'),
(57, '2015-06-25 18:30:58', 8, 'перенос раздела: добавть к', '8|9', 1, '', 'admin', '127.0.0.1'),
(56, '2015-06-25 18:24:46', 0, 'перенос раздела: добавть к', '8|9', 1, '', 'admin', '127.0.0.1'),
(85, '2015-06-25 23:10:09', 1, 'успешная авторизация', '', 1, '', 'admin', '127.0.0.1'),
(86, '2015-06-26 10:33:25', 1, 'успешная авторизация по кукам', '', 1, '', 'admin', '127.0.0.1'),
(87, '2015-06-29 22:10:55', 1, 'успешная авторизация по кукам', '', 1, '', 'admin', '127.0.0.1'),
(88, '2015-06-29 22:10:58', 1, 'выход из кабинета', '', 1, '', 'admin', '127.0.0.1'),
(89, '2015-06-30 17:09:53', 1, 'успешная авторизация по кукам', '', 1, '', 'admin', '127.0.0.1'),
(90, '2015-06-30 17:10:02', 1, 'редактирование пользователя', '', 1, '', 'admin', '127.0.0.1'),
(91, '2015-06-30 17:10:04', 1, 'выход из кабинета', '', 1, '', 'admin', '127.0.0.1'),
(92, '2015-06-30 17:10:09', 1, 'успешная авторизация', '', 1, '', 'admin', '127.0.0.1'),
(93, '2015-06-30 19:17:11', 4, 'редактирование настройки', 'counters|333|', 1, '', 'admin', '127.0.0.1'),
(94, '2015-06-30 19:17:27', 0, 'добавление настройки', 'phone|Телефон', 1, '', 'admin', '127.0.0.1'),
(95, '2015-06-30 19:17:39', 0, 'добавление настройки', 'email|Email', 1, '', 'admin', '127.0.0.1'),
(96, '2015-07-12 00:01:07', 5, 'редактирование настройки', 'log_enable|0|1', 1, '', 'admin', '127.0.0.1'),
(97, '2015-07-12 00:03:38', 5, 'редактирование настройки', 'log_enable|0|1', 1, '', 'admin', '127.0.0.1'),
(98, '2015-07-12 00:04:21', 4, 'редактирование настройки', 'counters||123', 1, '', 'admin', '127.0.0.1'),
(99, '2015-07-12 00:04:21', 5, 'редактирование настройки', 'log_enable|1|0', 1, '', 'admin', '127.0.0.1'),
(100, '2015-07-12 00:04:26', 5, 'редактирование настройки', 'log_enable|0|1', 1, '', 'admin', '127.0.0.1'),
(101, '2015-07-12 00:06:10', 5, 'редактирование настройки', 'log_enable|0|1', 1, '', 'admin', '127.0.0.1'),
(102, '2015-07-12 00:10:41', 0, 'добавление настройки', '2|1', 1, '', 'admin', '127.0.0.1'),
(103, '2015-07-12 00:10:45', 10, 'редактирование настройки', '2|3|3123', 1, '', 'admin', '127.0.0.1'),
(104, '2015-07-12 00:10:49', 10, 'удаление настройки', '', 1, '', 'admin', '127.0.0.1'),
(105, '2015-07-12 00:32:11', 1, 'успешная авторизация', '', 1, '', 'admin', '127.0.0.1'),
(106, '2015-07-12 00:32:29', 1, 'выход из кабинета', '', 1, '', 'admin', '127.0.0.1'),
(107, '2015-07-12 11:15:44', 1, 'успешная авторизация по кукам', '', 1, '', 'admin', '127.0.0.1'),
(108, '2015-07-12 11:40:24', 0, 'добавление раздела', '1', 1, '', 'admin', '127.0.0.1'),
(109, '2015-07-12 11:40:34', 23, 'удаление раздела', '1', 1, '', 'admin', '127.0.0.1'),
(110, '2015-07-12 11:47:07', 3, 'редактирование свойств раздела', 'Доступ', 1, '', 'admin', '127.0.0.1'),
(111, '2015-07-12 11:47:47', 7, 'редактирование свойств раздела', 'Контакты', 1, '', 'admin', '127.0.0.1'),
(112, '2015-07-12 11:50:00', 3, 'редактирование свойств раздела', 'Доступ', 1, '', 'admin', '127.0.0.1'),
(113, '2015-07-12 11:50:15', 0, 'добавление раздела', '1', 1, '', 'admin', '127.0.0.1'),
(114, '2015-07-12 11:50:21', 24, 'редактирование свойств раздела', '1', 1, '', 'admin', '127.0.0.1'),
(115, '2015-07-12 11:50:26', 24, 'удаление раздела', '1', 1, '', 'admin', '127.0.0.1'),
(116, '2015-07-12 11:54:50', 22, 'редактирование свойств раздела', '1', 1, '', 'admin', '127.0.0.1'),
(117, '2015-07-12 11:55:28', 22, 'редактирование свойств раздела', '1', 1, '', 'admin', '127.0.0.1'),
(118, '2015-07-12 11:55:33', 22, 'редактирование свойств раздела', '1', 1, '', 'admin', '127.0.0.1'),
(119, '2015-07-12 11:55:37', 22, 'удаление раздела', '22', 1, '', 'admin', '127.0.0.1'),
(120, '2015-07-12 11:55:45', 0, 'добавление раздела', '1', 1, '', 'admin', '127.0.0.1'),
(121, '2015-07-12 11:55:49', 25, 'редактирование свойств раздела', '1', 1, '', 'admin', '127.0.0.1'),
(122, '2015-07-12 11:55:52', 25, 'редактирование свойств раздела', '1', 1, '', 'admin', '127.0.0.1'),
(123, '2015-07-12 11:58:06', 0, 'добавление настройки', '2|1', 1, '', 'admin', '127.0.0.1'),
(124, '2015-07-12 11:58:10', 11, 'редактирование настройки', '2|2|2222', 1, '', 'admin', '127.0.0.1'),
(125, '2015-07-12 11:58:14', 11, 'удаление настройки', '', 1, '', 'admin', '127.0.0.1'),
(126, '2015-07-12 12:01:41', 11, 'удаление настройки', '', 1, '', 'admin', '127.0.0.1'),
(127, '2015-07-12 12:09:54', 1, 'редактирование пользователя', '', 1, '', 'admin', '127.0.0.1'),
(128, '2015-07-12 12:18:14', 0, 'добавление пользователя', '123', 1, '', 'admin', '127.0.0.1'),
(129, '2015-07-12 12:18:17', 0, 'добавление пользователя', '123', 1, '', 'admin', '127.0.0.1'),
(130, '2015-07-12 12:18:22', 4, 'удаление пользователя', '', 1, '', 'admin', '127.0.0.1'),
(131, '2015-07-12 12:25:54', 25, 'удаление раздела', '12', 1, '', 'admin', '127.0.0.1'),
(132, '2015-07-12 12:34:21', 6, 'редактирование свойств раздела', 'Содержимое сайта', 1, '', 'admin', '127.0.0.1');

-- --------------------------------------------------------

--
-- Структура таблицы `site_settings`
--

CREATE TABLE IF NOT EXISTS `site_settings` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `value` text,
  `settings` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=10 ;

--
-- Дамп данных таблицы `site_settings`
--

INSERT INTO `site_settings` (`id`, `name`, `description`, `value`, `settings`) VALUES
(1, 'pub_page_count', 'Количество элементов на странице типа «Лента»', '20', '|type=integer|notnull|undeletable|'),
(2, 'address', 'Адрес', 'Пермь, Решетникова 4', '|type=string|'),
(3, 'address_comment', 'Комментарий к маркеру на карте', '3-ий этаж, офис 304', '|type=string|'),
(4, 'counters', 'Счетчики', '123', '|type=text|'),
(5, 'log_enable', 'Вести лог событий', '0', '|type=int|'),
(6, 'pr_doptit', 'Дополнение к title (кроме главной)', 'имя-сайта.ru', '|type=string|'),
(8, 'phone', 'Телефон', '', '|type=string|'),
(9, 'email', 'Email', '', '|type=string|');

-- --------------------------------------------------------

--
-- Структура таблицы `site_site_data_sets`
--

CREATE TABLE IF NOT EXISTS `site_site_data_sets` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `settings` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=15 ;

--
-- Дамп данных таблицы `site_site_data_sets`
--

INSERT INTO `site_site_data_sets` (`id`, `description`, `name`, `settings`) VALUES
(1, 'Лист (1 колонка)', 'sheet1', ''),
(2, 'Справочник', 'spr', ''),
(3, 'Публикация', 'publication', ''),
(4, 'Список с картинками расширенный', 'imagelistext', ''),
(5, 'Справочник расширенный', 'sprext', ''),
(6, 'Архив газеты', 'archive', ''),
(7, 'Список с картинками', 'imagelist', ''),
(8, 'Видео', 'video', ''),
(9, 'Новости', 'news', ''),
(10, 'Справочник с порядком', 'sprorder', ''),
(11, 'Произвольные страницы', 'pages', ''),
(12, 'Рубрикатор', 'rubricator', ''),
(13, 'Лента с категориями и порядком', 'newscat', ''),
(14, 'Баннеры', 'banners', '');

-- --------------------------------------------------------

--
-- Структура таблицы `site_site_data_types`
--

CREATE TABLE IF NOT EXISTS `site_site_data_types` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `dataset` bigint(20) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `precedence` bigint(20) DEFAULT NULL,
  `settings` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=75 ;

--
-- Дамп данных таблицы `site_site_data_types`
--

INSERT INTO `site_site_data_types` (`id`, `dataset`, `description`, `name`, `type`, `precedence`, `settings`) VALUES
(1, 1, 'Текст', 'text', 'CDTextEditor', 0, '|important|texttype=full|'),
(2, 2, 'Заголовок', 'name', 'CDText', 0, '|important|'),
(3, 2, 'Описание', 'description', 'CDText', 1, ''),
(4, 3, 'Дата', 'date', 'CDDate', 0, ''),
(5, 3, 'Заголовок', 'header', 'CDText', 1, '|important|'),
(6, 3, 'Анонс', 'short', 'CDText', 2, '|important|'),
(7, 3, 'Текст', 'text', 'CDTextEditor', 3, '|important|texttype=full|'),
(8, 3, 'Теги, разделитель -"|"', 'tags', 'CDText', 4, ''),
(9, 4, 'Наименование', 'name', 'CDText', 0, ''),
(10, 4, 'Изображение (280x300)', 'image', 'CDImage', 1, ''),
(11, 4, 'Описание', 'descr', 'CDTextEditor', 2, '|texttype=full|'),
(12, 4, 'Ссылка', 'url', 'CDText', 3, ''),
(13, 4, 'Дополнительная информация', 'dopinfo', 'CDText', 4, ''),
(14, 4, 'Изображение большое', 'big_image', 'CDImage', 1, ''),
(15, 5, 'Наименование', 'name', 'CDText', 0, '|important=1|'),
(16, 5, 'Доп 1', 'dop1', 'CDText', 1, ''),
(17, 5, 'Доп 2', 'dop2', 'CDText', 2, ''),
(18, 5, 'Доп 3', 'dop3', 'CDText', 3, ''),
(19, 5, 'Краткое описание', 'short', 'CDTextArea', 4, ''),
(20, 5, 'Описание', 'text', 'CDTextEditor', 5, '|texttype=full|'),
(21, 5, 'Псеводоним ссылки', 'pseudolink', 'CDText', 6, ''),
(22, 5, 'Title страницы', 'ptitle', 'CDText', 7, ''),
(23, 5, 'Description страницы', 'pdescription', 'CDText', 8, ''),
(24, 5, 'Картинка', 'image', 'CDImage', 9, ''),
(25, 6, 'Дата выхода', 'date', 'CDDate', 0, ''),
(26, 6, 'Номер', 'num', 'CDText', 1, '|0=|important||'),
(27, 6, 'PDF файл', 'pdf', 'CDFile', 2, '|texttype=full|'),
(28, 6, 'Год', 'year', 'CDText', 3, '|0=|important||'),
(29, 6, 'Описание', 'text', 'CDTextEditor', 4, '|texttype=full|'),
(30, 7, 'Наименование', 'name', 'CDText', 0, ''),
(31, 7, 'Изображение', 'image', 'CDImage', 1, ''),
(32, 7, 'Ссылка', 'url', 'CDText', 2, ''),
(33, 7, 'Дополнительная информация', 'dopinfo', 'CDText', 3, ''),
(34, 8, 'Наименование', 'name', 'CDText', 0, ''),
(35, 8, 'Изображение', 'image', 'CDImage', 1, '|important=1|'),
(36, 8, 'Код видеоролика', 'code', 'CDTextEditor', 2, '|texttype=full|important=1|'),
(37, 8, 'Описание видеоролика', 'descr', 'CDTextEditor', 3, '|texttype=full|'),
(38, 8, 'Ссылка', 'url', 'CDText', 4, ''),
(39, 8, 'Дополнительная информация', 'dopinfo', 'CDText', 5, ''),
(40, 9, 'Дата', 'date', 'CDDate', 0, ''),
(41, 9, 'Картинка', 'image', 'CDImage', 1, ''),
(42, 9, 'Заголовок', 'header', 'CDText', 2, '|important=1|'),
(43, 9, 'Анонс', 'short', 'CDTextArea', 3, ''),
(44, 9, 'Текст', 'text', 'CDTextEditor', 4, '|texttype=full|'),
(45, 9, 'Title страницы', 'ptitle', 'CDText', 5, ''),
(46, 9, 'Description страницы', 'pdescription', 'CDText', 6, ''),
(47, 9, 'Псеводоним ссылки', 'pseudolink', 'CDText', 7, ''),
(48, 10, 'Заголовок', 'name', 'CDText', 0, '|important=1|'),
(49, 10, 'Описание', 'description', 'CDText', 1, ''),
(50, 11, 'Название', 'name', 'CDText', 0, '|important=1|'),
(51, 11, 'Текст', 'text', 'CDTextEditor', 1, '|texttype=full|'),
(52, 11, 'Title страницы', 'ptitle', 'CDText', 2, ''),
(53, 11, 'Description страницы', 'pdescription', 'CDText', 3, ''),
(54, 11, 'Псеводоним ссылки', 'pseudolink', 'CDText', 4, ''),
(55, 12, 'Наименование', 'name', 'CDText', 0, '|0=|important||'),
(56, 12, 'Картинка', 'image', 'CDImage', 1, '|auto_resize=true|auto_width=50|auto_height=200|'),
(57, 12, 'Текст', 'text', 'CDTextEditor', 2, '|texttype=full|'),
(58, 12, 'Title страницы', 'ptitle', 'CDText', 3, ''),
(59, 12, 'Description страницы', 'pdescription', 'CDText', 4, ''),
(60, 12, 'Псеводоним ссылки', 'pseudolink', 'CDText', 5, ''),
(61, 13, 'Дата', 'date', 'CDDate', 0, ''),
(62, 13, 'Категория', 'cat_id', 'CDInteger', 1, ''),
(63, 13, 'Картинка', 'image', 'CDImage', 2, ''),
(64, 13, 'Заголовок', 'header', 'CDText', 3, '|important=1|'),
(65, 13, 'Анонс', 'short', 'CDTextArea', 4, ''),
(66, 13, 'Текст', 'text', 'CDTextEditor', 5, '|texttype=full|'),
(67, 13, 'Title страницы', 'ptitle', 'CDText', 6, ''),
(68, 13, 'Description страницы', 'pdescription', 'CDText', 7, ''),
(69, 13, 'Псеводоним ссылки', 'pseudolink', 'CDText', 8, ''),
(70, 14, 'Название клиента', 'name', 'CDText', 0, '|important=1|'),
(71, 14, 'Ссылка', 'href', 'CDText', 1, ''),
(72, 14, 'Баннер', 'image', 'CDImage', 2, ''),
(73, 14, 'Дата с', 'startdate', 'CDDate', 3, ''),
(74, 14, 'Дата по', 'enddate', 'CDDate', 4, '');

-- --------------------------------------------------------

--
-- Структура таблицы `site_site_pnews_news_8`
--

CREATE TABLE IF NOT EXISTS `site_site_pnews_news_8` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `show` int(1) DEFAULT NULL,
  `precedence` bigint(20) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `image` bigint(20) DEFAULT NULL,
  `header` varchar(255) DEFAULT NULL,
  `short` text,
  `text` text,
  `ptitle` varchar(255) DEFAULT NULL,
  `pdescription` varchar(255) DEFAULT NULL,
  `pseudolink` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `site_site_pnews_news_8`
--

INSERT INTO `site_site_pnews_news_8` (`id`, `show`, `precedence`, `date`, `image`, `header`, `short`, `text`, `ptitle`, `pdescription`, `pseudolink`) VALUES
(1, 1, 1, '2015-07-12', 0, '1', '', '', '', '', '1'),
(2, 1, 0, '2015-07-12', 0, '2', '', '', '', '', '2');

-- --------------------------------------------------------

--
-- Структура таблицы `site_site_psheet1_sheet1`
--

CREATE TABLE IF NOT EXISTS `site_site_psheet1_sheet1` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `section_id` bigint(20) DEFAULT NULL,
  `text` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `site_site_psheet1_sheet1`
--


-- --------------------------------------------------------

--
-- Структура таблицы `site_site_sections`
--

CREATE TABLE IF NOT EXISTS `site_site_sections` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `pattern` varchar(255) DEFAULT NULL,
  `parent` bigint(20) DEFAULT NULL,
  `precedence` bigint(20) DEFAULT NULL,
  `isservice` int(1) DEFAULT NULL,
  `keywords` text,
  `title` text,
  `tags` text,
  `description` text,
  `visible` tinyint(6) DEFAULT NULL,
  `settings` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=9 ;

--
-- Дамп данных таблицы `site_site_sections`
--

INSERT INTO `site_site_sections` (`id`, `name`, `path`, `pattern`, `parent`, `precedence`, `isservice`, `keywords`, `title`, `tags`, `description`, `visible`, `settings`) VALUES
(1, 'Управление сайтом', 'control', 'PFolder', 0, -1, 1, '', '', '', '', 0, '|nopathchange|nodestination|undrop|undeletable|enable_actions=view,add,edit,delete|'),
(2, 'Настройки', 'settings', 'PFolder', 1, -1, 1, '', '', '', '', 1, '|nopathchange|nodestination|undrop|undeletable|enable_actions=view,add,edit,delete|'),
(3, 'Доступ', 'access', 'PFolder', 0, -1, 1, '', '', '', '', 1, '|nopathchange|nodestination|undrop|undeletable|enable_actions=view,add,edit,delete|'),
(4, 'Пользователи', 'users', 'PFolder', 3, -1, 1, '', '', '', '', 1, '|nopathchange|nodestination|undrop|undeletable|enable_actions=onoff,view,add,edit,delete|'),
(5, 'Группы', 'groups', 'PFolder', 3, -1, 1, '', '', '', '', 1, '|nopathchange|nodestination|undrop|undeletable|enable_actions=view,add,edit,delete|'),
(6, 'Содержимое сайта', 'sitecontent', 'PFolder', 0, 1, 0, '', 'Разработка сайтов в Перми, продвижение сайтов', '', 'Разработка сайтов в Перми, продвижение сайтов', 0, '|nopathchange|nodestination|undrop|undeletable|enable_actions=view,add,edit,delete|'),
(7, 'Логи действий', 'log', 'PLog', 1, 0, 1, '', '', '', '', 1, '|nopathchange|nodestination|undrop|undeletable|'),
(8, 'Тест', 'test', 'PNews', 6, 0, 0, '', '', '', '', 0, '|nopathchange|nodestination|undrop|undeletable|');

-- --------------------------------------------------------

--
-- Структура таблицы `site_storages_files`
--

CREATE TABLE IF NOT EXISTS `site_storages_files` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `stid` text,
  `name` varchar(255) DEFAULT NULL,
  `theme` varchar(255) DEFAULT NULL,
  `rubric` varchar(255) DEFAULT NULL,
  `uid` bigint(20) DEFAULT NULL,
  `settings` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=129 ;

--
-- Дамп данных таблицы `site_storages_files`
--

INSERT INTO `site_storages_files` (`id`, `stid`, `name`, `theme`, `rubric`, `uid`, `settings`) VALUES
(89, '2', 'temp_2mum7kt3i.jpg', 'imagelist_18', 'image', 0, NULL),
(90, '2', 'temp_uf7cw0gefp.jpg', 'imagelist_18', 'image', 0, NULL),
(91, '2', 'temp_ernjy27mc.jpg', 'imagelist_18', 'image', 0, NULL),
(92, '2', 'temp_lec99lltgl.jpg', 'imagelist_18', 'image', 0, NULL),
(93, '2', 'temp_5kgv03ijvl.jpg', 'imagelist_18', 'image', 0, NULL),
(94, '2', 'temp_qs5ruc5oe.jpg', 'imagelist_18', 'image', 0, NULL),
(96, '2', 'temp_5udnintiq3.jpg', 'imagelist_18', 'image', 0, NULL),
(97, '2', 'temp_h6w7jl305.jpg', 'imagelist_18', 'image', 0, NULL),
(98, '2', 'temp_xmmxhnjddd.jpg', 'imagelist_18', 'image', 0, NULL),
(99, '2', 'temp_wf6i1lxbqt.jpg', 'imagelist_18', 'image', 0, NULL),
(100, '2', 'temp_cggkf7yts7.jpg', 'imagelist_18', 'image', 0, NULL),
(101, '2', 'temp_l1jp97h8p.jpg', 'imagelist_18', 'image', 0, NULL),
(105, '2', 'temp_9y6v7qhe4.jpg', 'imagelist_18', 'image', 0, NULL),
(107, '2', 'temp_lzb2cewik0.jpg', 'imagelist_18', 'image', 0, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `site_storages_info`
--

CREATE TABLE IF NOT EXISTS `site_storages_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `path` text,
  `name` text,
  `settings` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `site_storages_info`
--

INSERT INTO `site_storages_info` (`id`, `path`, `name`, `settings`) VALUES
(1, '/storage/users/icons/', 'Иконки для пользователей бэк-офиса', '|images|maxsize=10240|imgw=60|imgwtype=1|imgh=60|imghtype=1|exts=jpg,gif,jpeg|'),
(2, '/storage/site/images/', 'Изображения сайта (общее)', '|images|maxsize=10240|exts=jpg,gif,jpeg,png|'),
(3, '/storage/site/files/', 'Файлы сайта (общее)', '|maxsize=10240|'),
(4, '/storage/site/pdf/', 'Файлы сайта (общее)', '|maxsize=10240|exts=pdf|'),
(5, '/storage/site/banners/200_290/', 'Баннеры', '|images|maxsize=10240|imgw=300|imgwtype=1|imgh=200|imghtype=1|exts=jpg,gif,jpeg,png,swf|'),
(6, '/storage/site/banners/', 'Баннеры', '|maxsize=10240|exts=jpg,gif,jpeg,png,swf|');
