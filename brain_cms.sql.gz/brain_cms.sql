-- phpMyAdmin SQL Dump
-- version 3.3.10
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Авг 27 2015 г., 20:29
-- Версия сервера: 5.5.11
-- Версия PHP: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `brain_cms`
--

-- --------------------------------------------------------

--
-- Структура таблицы `pr_banners_clicks`
--

CREATE TABLE IF NOT EXISTS `pr_banners_clicks` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `section_id` bigint(20) NOT NULL,
  `banner_id` bigint(20) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `num` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`banner_id`),
  KEY `date` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `pr_banners_clicks`
--


-- --------------------------------------------------------

--
-- Структура таблицы `pr_banners_shows`
--

CREATE TABLE IF NOT EXISTS `pr_banners_shows` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `section_id` bigint(20) NOT NULL,
  `banner_id` bigint(20) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `num` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`banner_id`),
  KEY `date` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `pr_banners_shows`
--


-- --------------------------------------------------------

--
-- Структура таблицы `site_bk_users_info`
--

CREATE TABLE IF NOT EXISTS `site_bk_users_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `regdate` date DEFAULT NULL,
  `login` varchar(255) DEFAULT NULL,
  `pswd` varchar(255) DEFAULT NULL,
  `type` bigint(20) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `secondname` varchar(255) DEFAULT NULL,
  `parentname` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `picture` bigint(20) DEFAULT NULL,
  `settings` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `site_bk_users_info`
--

INSERT INTO `site_bk_users_info` (`id`, `regdate`, `login`, `pswd`, `type`, `firstname`, `secondname`, `parentname`, `email`, `picture`, `settings`) VALUES
(1, '2011-05-25', 'admin', '039a8f73e1e5dcf7663d4ef8db24ece4', 1, 'admin', 'admin', 'admin', '', 0, '|engage|notypechange|norename|nologinchange|undeletable|noswitch|help=users_mainadmin|lasttime=1440677138|'),
(2, '2015-06-23', 'director', '3d4e992d8d8a7d848724aa26ed7f4176', 2, 'director', 'director', 'director', '', 0, '|lasttime=1438180966|engage|'),
(3, '2015-06-25', 'user', 'ee11cbb19052e40b07aac0ca060c23ee', 3, 'user', 'user', 'user', '', 0, '|engage|lasttime=1436707289|');

-- --------------------------------------------------------

--
-- Структура таблицы `site_bk_users_types`
--

CREATE TABLE IF NOT EXISTS `site_bk_users_types` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `access` text,
  `settings` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `site_bk_users_types`
--

INSERT INTO `site_bk_users_types` (`id`, `name`, `access`, `settings`) VALUES
(1, 'Разработчики', '', '|undeletable|superaccess|noedit|help=usergroups_admins|'),
(2, 'Администраторы', '|3=|5=view,add,edit,delete|4=onoff,view,add,edit,delete|1=|2=view,add,edit,delete|7=|6=|11=view|19=view,add,edit,delete|13=view|14=|18=view,add,edit,delete|', NULL),
(3, 'Пользователи', '|6=|7=|8=|9=|10=|11=|13=|', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `site_log`
--

CREATE TABLE IF NOT EXISTS `site_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `item_id` bigint(20) NOT NULL,
  `descr` varchar(255) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `changes` text,
  `user_name` varchar(255) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_num` (`item_id`),
  KEY `descr` (`descr`),
  KEY `date` (`date`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=133 ;

--
-- Дамп данных таблицы `site_log`
--

INSERT INTO `site_log` (`id`, `date`, `item_id`, `descr`, `comment`, `user_id`, `changes`, `user_name`, `ip`) VALUES
(84, '2015-06-25 23:10:04', 2, 'выход из кабинета', '', 2, '', 'director', '127.0.0.1'),
(82, '2015-06-25 23:09:42', 1, 'выход из кабинета', '', 1, '', 'admin', '127.0.0.1'),
(83, '2015-06-25 23:09:50', 2, 'успешная авторизация', '', 2, '', 'director', '127.0.0.1'),
(81, '2015-06-25 23:09:31', 2, 'редактирование группы', 'Администраторы', 1, '', 'admin', '127.0.0.1'),
(80, '2015-06-25 23:09:12', 5, 'редактирование настройки', 'log_enable|0|1', 1, '', 'admin', '127.0.0.1'),
(79, '2015-06-25 23:08:56', 21, 'редактирование свойств раздела', 'Страница', 1, '', 'admin', '127.0.0.1'),
(78, '2015-06-25 23:08:54', 21, 'редактирование свойств раздела', 'Страница', 1, '', 'admin', '127.0.0.1'),
(77, '2015-06-25 23:08:40', 21, 'перенос раздела: добавть к', '21|6', 1, '', 'admin', '127.0.0.1'),
(76, '2015-06-25 23:08:37', 0, 'добавление раздела', 'Страница', 1, '', 'admin', '127.0.0.1'),
(75, '2015-06-25 23:08:22', 15, 'удаление раздела', 'Новый разд', 1, '', 'admin', '127.0.0.1'),
(74, '2015-06-25 23:08:17', 9, 'удаление раздела', 'Заказать сайт', 1, '', 'admin', '127.0.0.1'),
(73, '2015-06-25 23:08:01', 19, 'удаление раздела', '1', 1, '', 'admin', '127.0.0.1'),
(72, '2015-06-25 23:04:57', 17, 'удаление раздела', '55555', 1, '', 'admin', '127.0.0.1'),
(71, '2015-06-25 22:57:44', 20, 'удаление раздела', '1', 1, '', 'admin', '127.0.0.1'),
(70, '2015-06-25 22:57:38', 6, 'редактирование свойств раздела', 'Содержимое сайта', 1, '', 'admin', '127.0.0.1'),
(69, '2015-06-25 21:08:25', 20, 'перенос раздела: добавть к', '20|6', 1, '', 'admin', '127.0.0.1'),
(68, '2015-06-25 21:08:20', 19, 'перенос раздела: добавть к', '19|6', 1, '', 'admin', '127.0.0.1'),
(67, '2015-06-25 21:08:14', 0, 'добавление раздела', '1', 1, '', 'admin', '127.0.0.1'),
(66, '2015-06-25 19:20:21', 0, 'добавление раздела', '1', 1, '', 'admin', '127.0.0.1'),
(65, '2015-06-25 19:20:08', 10, 'удаление раздела', 'Портфолио', 1, '', 'admin', '127.0.0.1'),
(63, '2015-06-25 18:41:49', 18, 'перенос раздела: добавть к', '18|6', 1, '', 'admin', '127.0.0.1'),
(64, '2015-06-25 19:01:50', 18, 'перенос раздела: добавть к', '18|6', 1, '', 'admin', '127.0.0.1'),
(62, '2015-06-25 18:41:46', 0, 'добавление раздела', 'Тестовый', 1, '', 'admin', '127.0.0.1'),
(59, '2015-06-25 18:32:33', 8, 'перенос раздела: добавть к', '8|9', 1, '', 'admin', '127.0.0.1'),
(60, '2015-06-25 18:32:37', 8, 'перенос раздела: добавть к', '8|7', 1, '', 'admin', '127.0.0.1'),
(61, '2015-06-25 18:32:54', 8, 'удаление раздела', 'Цены', 1, '', 'admin', '127.0.0.1'),
(58, '2015-06-25 18:32:29', 8, 'перенос раздела: добавть к', '8|9', 1, '', 'admin', '127.0.0.1'),
(57, '2015-06-25 18:30:58', 8, 'перенос раздела: добавть к', '8|9', 1, '', 'admin', '127.0.0.1'),
(56, '2015-06-25 18:24:46', 0, 'перенос раздела: добавть к', '8|9', 1, '', 'admin', '127.0.0.1'),
(85, '2015-06-25 23:10:09', 1, 'успешная авторизация', '', 1, '', 'admin', '127.0.0.1'),
(86, '2015-06-26 10:33:25', 1, 'успешная авторизация по кукам', '', 1, '', 'admin', '127.0.0.1'),
(87, '2015-06-29 22:10:55', 1, 'успешная авторизация по кукам', '', 1, '', 'admin', '127.0.0.1'),
(88, '2015-06-29 22:10:58', 1, 'выход из кабинета', '', 1, '', 'admin', '127.0.0.1'),
(89, '2015-06-30 17:09:53', 1, 'успешная авторизация по кукам', '', 1, '', 'admin', '127.0.0.1'),
(90, '2015-06-30 17:10:02', 1, 'редактирование пользователя', '', 1, '', 'admin', '127.0.0.1'),
(91, '2015-06-30 17:10:04', 1, 'выход из кабинета', '', 1, '', 'admin', '127.0.0.1'),
(92, '2015-06-30 17:10:09', 1, 'успешная авторизация', '', 1, '', 'admin', '127.0.0.1'),
(93, '2015-06-30 19:17:11', 4, 'редактирование настройки', 'counters|333|', 1, '', 'admin', '127.0.0.1'),
(94, '2015-06-30 19:17:27', 0, 'добавление настройки', 'phone|Телефон', 1, '', 'admin', '127.0.0.1'),
(95, '2015-06-30 19:17:39', 0, 'добавление настройки', 'email|Email', 1, '', 'admin', '127.0.0.1'),
(96, '2015-07-12 00:01:07', 5, 'редактирование настройки', 'log_enable|0|1', 1, '', 'admin', '127.0.0.1'),
(97, '2015-07-12 00:03:38', 5, 'редактирование настройки', 'log_enable|0|1', 1, '', 'admin', '127.0.0.1'),
(98, '2015-07-12 00:04:21', 4, 'редактирование настройки', 'counters||123', 1, '', 'admin', '127.0.0.1'),
(99, '2015-07-12 00:04:21', 5, 'редактирование настройки', 'log_enable|1|0', 1, '', 'admin', '127.0.0.1'),
(100, '2015-07-12 00:04:26', 5, 'редактирование настройки', 'log_enable|0|1', 1, '', 'admin', '127.0.0.1'),
(101, '2015-07-12 00:06:10', 5, 'редактирование настройки', 'log_enable|0|1', 1, '', 'admin', '127.0.0.1'),
(102, '2015-07-12 00:10:41', 0, 'добавление настройки', '2|1', 1, '', 'admin', '127.0.0.1'),
(103, '2015-07-12 00:10:45', 10, 'редактирование настройки', '2|3|3123', 1, '', 'admin', '127.0.0.1'),
(104, '2015-07-12 00:10:49', 10, 'удаление настройки', '', 1, '', 'admin', '127.0.0.1'),
(105, '2015-07-12 00:32:11', 1, 'успешная авторизация', '', 1, '', 'admin', '127.0.0.1'),
(106, '2015-07-12 00:32:29', 1, 'выход из кабинета', '', 1, '', 'admin', '127.0.0.1'),
(107, '2015-07-12 11:15:44', 1, 'успешная авторизация по кукам', '', 1, '', 'admin', '127.0.0.1'),
(108, '2015-07-12 11:40:24', 0, 'добавление раздела', '1', 1, '', 'admin', '127.0.0.1'),
(109, '2015-07-12 11:40:34', 23, 'удаление раздела', '1', 1, '', 'admin', '127.0.0.1'),
(110, '2015-07-12 11:47:07', 3, 'редактирование свойств раздела', 'Доступ', 1, '', 'admin', '127.0.0.1'),
(111, '2015-07-12 11:47:47', 7, 'редактирование свойств раздела', 'Контакты', 1, '', 'admin', '127.0.0.1'),
(112, '2015-07-12 11:50:00', 3, 'редактирование свойств раздела', 'Доступ', 1, '', 'admin', '127.0.0.1'),
(113, '2015-07-12 11:50:15', 0, 'добавление раздела', '1', 1, '', 'admin', '127.0.0.1'),
(114, '2015-07-12 11:50:21', 24, 'редактирование свойств раздела', '1', 1, '', 'admin', '127.0.0.1'),
(115, '2015-07-12 11:50:26', 24, 'удаление раздела', '1', 1, '', 'admin', '127.0.0.1'),
(116, '2015-07-12 11:54:50', 22, 'редактирование свойств раздела', '1', 1, '', 'admin', '127.0.0.1'),
(117, '2015-07-12 11:55:28', 22, 'редактирование свойств раздела', '1', 1, '', 'admin', '127.0.0.1'),
(118, '2015-07-12 11:55:33', 22, 'редактирование свойств раздела', '1', 1, '', 'admin', '127.0.0.1'),
(119, '2015-07-12 11:55:37', 22, 'удаление раздела', '22', 1, '', 'admin', '127.0.0.1'),
(120, '2015-07-12 11:55:45', 0, 'добавление раздела', '1', 1, '', 'admin', '127.0.0.1'),
(121, '2015-07-12 11:55:49', 25, 'редактирование свойств раздела', '1', 1, '', 'admin', '127.0.0.1'),
(122, '2015-07-12 11:55:52', 25, 'редактирование свойств раздела', '1', 1, '', 'admin', '127.0.0.1'),
(123, '2015-07-12 11:58:06', 0, 'добавление настройки', '2|1', 1, '', 'admin', '127.0.0.1'),
(124, '2015-07-12 11:58:10', 11, 'редактирование настройки', '2|2|2222', 1, '', 'admin', '127.0.0.1'),
(125, '2015-07-12 11:58:14', 11, 'удаление настройки', '', 1, '', 'admin', '127.0.0.1'),
(126, '2015-07-12 12:01:41', 11, 'удаление настройки', '', 1, '', 'admin', '127.0.0.1'),
(127, '2015-07-12 12:09:54', 1, 'редактирование пользователя', '', 1, '', 'admin', '127.0.0.1'),
(128, '2015-07-12 12:18:14', 0, 'добавление пользователя', '123', 1, '', 'admin', '127.0.0.1'),
(129, '2015-07-12 12:18:17', 0, 'добавление пользователя', '123', 1, '', 'admin', '127.0.0.1'),
(130, '2015-07-12 12:18:22', 4, 'удаление пользователя', '', 1, '', 'admin', '127.0.0.1'),
(131, '2015-07-12 12:25:54', 25, 'удаление раздела', '12', 1, '', 'admin', '127.0.0.1'),
(132, '2015-07-12 12:34:21', 6, 'редактирование свойств раздела', 'Содержимое сайта', 1, '', 'admin', '127.0.0.1');

-- --------------------------------------------------------

--
-- Структура таблицы `site_settings`
--

CREATE TABLE IF NOT EXISTS `site_settings` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `value` text,
  `settings` text,
  `precedence` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=12 ;

--
-- Дамп данных таблицы `site_settings`
--

INSERT INTO `site_settings` (`id`, `name`, `description`, `value`, `settings`, `precedence`) VALUES
(1, 'pub_page_count', 'Количество элементов на странице типа «Лента»', '20', '|type=integer|notnull|undeletable|', 4),
(2, 'address', 'Адрес', 'Пермь, Решетникова 4', '|type=string|', 1),
(3, 'address_comment', 'Комментарий к маркеру на карте', '3-ий этаж, офис 304', '|type=string|', 5),
(4, 'counters', 'Счетчики', '123', '|type=text|', 6),
(5, 'log_enable', 'Вести лог событий', '0', '|type=int|', 7),
(6, 'pr_doptit', 'Дополнение к title (кроме главной)', 'имя-сайта.ru', '|type=string|', 8),
(8, 'phone', 'Телефон', '', '|type=string|', 2),
(9, 'email', 'Email', '', '|type=string|', 3),
(10, 'admin_logo', 'Логотип для входа в панель', '0', '|type=image|', 9),
(11, 'photoalbum_page_count', 'Количество элементов на странице типа «Фото»', '18', '|type=integer|notnull|undeletable|', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `site_site_data_sets`
--

CREATE TABLE IF NOT EXISTS `site_site_data_sets` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `settings` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=48 ;

--
-- Дамп данных таблицы `site_site_data_sets`
--

INSERT INTO `site_site_data_sets` (`id`, `description`, `name`, `settings`) VALUES
(44, 'Лист (1 колонка)', 'sheet1', ''),
(47, 'Тестовый раздел', 'test', '');

-- --------------------------------------------------------

--
-- Структура таблицы `site_site_data_types`
--

CREATE TABLE IF NOT EXISTS `site_site_data_types` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `dataset` bigint(20) DEFAULT NULL,
  `section_id` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `precedence` bigint(20) DEFAULT NULL,
  `settings` text,
  `setting_style_edit` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=41 ;

--
-- Дамп данных таблицы `site_site_data_types`
--

INSERT INTO `site_site_data_types` (`id`, `dataset`, `section_id`, `description`, `name`, `type`, `precedence`, `settings`, `setting_style_edit`) VALUES
(26, 44, 0, 'Текст', 'text', 'CDTextEditor', 0, '|important|texttype=full|', ''),
(27, 47, 24, 'Наименование2', 'name2', 'CDText', 0, '|important|', ''),
(29, 47, 24, 'Счетчик', 'spinner', 'CDSpinner', 1, '|default=5|', ''),
(30, 47, 24, 'Слайдер', 'slider', 'CDSlider', 1, '|min=1|max=5|default=3|off|', ''),
(31, 47, 24, 'Выбор', 'choice', 'CDChoice', 1, '|type=radio|off|', ''),
(32, 47, 24, 'Множ. выбор', 'choice_milti', 'CDChoice', 1, '|type=multi|values=1#первый, 2#второй, 3#третий, 4#четвертый, 5#пятый|comment=выберите одно или несколько значений|', ''),
(34, 47, 25, 'Наименование', 'name', 'CDText', 6, '', ''),
(35, 47, 25, 'Показывать', 'enabled', 'CDBoolean', 7, '|default=1|', ''),
(36, 47, 25, 'Счетчик', 'spinner', 'CDSpinner', 8, '|default=5|', ''),
(37, 47, 25, 'Слайдер', 'slider', 'CDSlider', 9, '|min=1|max=5|default=3|', ''),
(38, 47, 25, 'Выбор', 'choice', 'CDChoice', 10, '|type=radio|', ''),
(39, 47, 25, 'Множ. выбор', 'choice_milti', 'CDChoice', 11, '|type=multi|values=1#первый, 2#второй, 3#третий, 4#четвертый, 5#пятый|comment=выберите одно или несколько значений|', ''),
(40, 47, 25, 'Множ. выбор - внешний массив', 'choice_milti2', 'CDChoice', 12, '|type=multi|', '');

-- --------------------------------------------------------

--
-- Структура таблицы `site_site_psheet1_sheet1`
--

CREATE TABLE IF NOT EXISTS `site_site_psheet1_sheet1` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `section_id` bigint(20) DEFAULT NULL,
  `text` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `site_site_psheet1_sheet1`
--


-- --------------------------------------------------------

--
-- Структура таблицы `site_site_ptest_test_24`
--

CREATE TABLE IF NOT EXISTS `site_site_ptest_test_24` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `show` int(1) DEFAULT NULL,
  `show_main` int(1) DEFAULT NULL,
  `precedence` bigint(20) DEFAULT NULL,
  `name2` varchar(255) DEFAULT NULL COMMENT 'Наименование2',
  `spinner` bigint(20) DEFAULT NULL,
  `slider` varchar(255) DEFAULT NULL,
  `choice` varchar(1000) DEFAULT NULL,
  `choice_milti` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `site_site_ptest_test_24`
--

INSERT INTO `site_site_ptest_test_24` (`id`, `show`, `show_main`, `precedence`, `name2`, `spinner`, `slider`, `choice`, `choice_milti`) VALUES
(1, 1, NULL, 0, '123', 5, '3', '', ',2,3,4,');

-- --------------------------------------------------------

--
-- Структура таблицы `site_site_ptest_test_25`
--

CREATE TABLE IF NOT EXISTS `site_site_ptest_test_25` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `show` int(1) DEFAULT NULL,
  `show_main` int(1) DEFAULT NULL,
  `precedence` bigint(20) DEFAULT NULL,
  `name2` varchar(255) DEFAULT NULL COMMENT 'Наименование2',
  `spinner` bigint(20) DEFAULT NULL,
  `slider` varchar(255) DEFAULT NULL,
  `choice` varchar(1000) DEFAULT NULL,
  `choice_milti` varchar(1000) DEFAULT NULL,
  `choice_milti2` varchar(1000) DEFAULT NULL,
  `new` varchar(255) DEFAULT NULL COMMENT 'new',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `site_site_ptest_test_25`
--

INSERT INTO `site_site_ptest_test_25` (`id`, `show`, `show_main`, `precedence`, `name2`, `spinner`, `slider`, `choice`, `choice_milti`, `choice_milti2`, `new`) VALUES
(1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `site_site_ptest_test_26`
--

CREATE TABLE IF NOT EXISTS `site_site_ptest_test_26` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `show` int(1) DEFAULT NULL,
  `show_main` int(1) DEFAULT NULL,
  `precedence` bigint(20) DEFAULT NULL,
  `name2` varchar(255) DEFAULT NULL COMMENT 'Наименование2',
  `spinner` bigint(20) DEFAULT NULL,
  `slider` varchar(255) DEFAULT NULL,
  `choice` varchar(1000) DEFAULT NULL,
  `choice_milti` varchar(1000) DEFAULT NULL,
  `choice_milti2` varchar(1000) DEFAULT NULL,
  `new` varchar(255) DEFAULT NULL COMMENT 'new',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `site_site_ptest_test_26`
--


-- --------------------------------------------------------

--
-- Структура таблицы `site_site_sections`
--

CREATE TABLE IF NOT EXISTS `site_site_sections` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `pattern` varchar(255) DEFAULT NULL,
  `parent` bigint(20) DEFAULT NULL,
  `precedence` bigint(20) DEFAULT NULL,
  `isservice` int(1) DEFAULT NULL,
  `keywords` text,
  `title` text,
  `tags` text,
  `description` text,
  `header` text,
  `visible` tinyint(6) DEFAULT NULL,
  `settings` text,
  `settings_personal` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=27 ;

--
-- Дамп данных таблицы `site_site_sections`
--

INSERT INTO `site_site_sections` (`id`, `name`, `path`, `pattern`, `parent`, `precedence`, `isservice`, `keywords`, `title`, `tags`, `description`, `header`, `visible`, `settings`, `settings_personal`) VALUES
(1, 'Управление сайтом', 'control', 'PFolder', 0, -1, 1, '', '', '', '', NULL, 0, '|nopathchange|nodestination|undrop|undeletable|enable_actions=view,add,edit,delete|', NULL),
(2, 'Настройки', 'settings', 'PFolder', 1, -1, 1, '', '', '', '', NULL, 1, '|nopathchange|nodestination|undrop|undeletable|enable_actions=view,add,edit,delete|', NULL),
(3, 'Доступ', 'access', 'PFolder', 0, -1, 1, '', '', '', '', NULL, 1, '|nopathchange|nodestination|undrop|undeletable|enable_actions=view,add,edit,delete|', NULL),
(4, 'Пользователи', 'users', 'PFolder', 3, -1, 1, '', '', '', '', NULL, 1, '|nopathchange|nodestination|undrop|undeletable|enable_actions=onoff,view,add,edit,delete|', NULL),
(5, 'Группы', 'groups', 'PFolder', 3, -1, 1, '', '', '', '', NULL, 1, '|nopathchange|nodestination|undrop|undeletable|enable_actions=view,add,edit,delete|', NULL),
(6, 'Содержимое сайта', 'sitecontent', 'PFolder', 0, 0, 0, '', '', '', '', NULL, 0, '|nopathchange|nodestination|undrop|undeletable|enable_actions=view,add,edit,delete|', NULL),
(7, 'Логи действий', 'log', 'PLog', 1, 0, 1, '', '', '', '', NULL, 1, '|nopathchange|nodestination|undrop|undeletable|', NULL),
(24, 'тест 1', 'test1', 'PTest', 6, 0, 0, '', '', '', '', NULL, 0, '|nopathchange|nodestination|undrop|undeletable|', ''),
(25, 'тест2', 'test2', 'PTest', 6, 1, 0, '', '', '', '', NULL, 0, '|nopathchange|nodestination|undrop|undeletable|', ''),
(26, 'тест3', 'test3', 'PTest', 6, 2, 0, '', '', '', '', NULL, 0, '|nopathchange|nodestination|undrop|undeletable|', '');

-- --------------------------------------------------------

--
-- Структура таблицы `site_storages_files`
--

CREATE TABLE IF NOT EXISTS `site_storages_files` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `stid` text,
  `name` varchar(255) DEFAULT NULL,
  `theme` varchar(255) DEFAULT NULL,
  `rubric` varchar(255) DEFAULT NULL,
  `uid` bigint(20) DEFAULT NULL,
  `settings` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=127 ;

--
-- Дамп данных таблицы `site_storages_files`
--

INSERT INTO `site_storages_files` (`id`, `stid`, `name`, `theme`, `rubric`, `uid`, `settings`) VALUES
(26, '2', 'temp_xwkwbovp1r.png', '0', '0', 0, NULL),
(27, '2', 'temp_bh3cs847kb.png', '0', '0', 0, NULL),
(28, '2', 'temp_8fiszv15ip.jpg', '0', '0', 0, NULL),
(29, '2', 'temp_u0eneppxid.png', '0', '0', 0, NULL),
(30, '2', 'temp_39iqkt0trd.png', '0', '0', 0, NULL),
(31, '2', 'temp_42t5ue0tvb.png', '0', '0', 0, NULL),
(32, '2', 'temp_8m1t0mch2.png', '0', '0', 0, NULL),
(36, '2', 'temp_n2xct1vod.png', '0', '0', 0, NULL),
(37, '2', 'temp_do9e555n7.png', '0', '0', 0, NULL),
(38, '2', 'temp_w0rco3hk48.jpg', '0', '0', 0, NULL),
(41, '2', 'temp_4etr6hlsq.png', '0', '0', 0, NULL),
(42, '5', 'temp_5uolr1x6p.jpg', 'test_11', 'images', 0, NULL),
(43, '5', 'temp_per29qjm0n.jpg', 'test_11', 'images', 0, NULL),
(44, '5', 'temp_h11306583x.jpg', 'test_11', 'images', 0, NULL),
(45, '5', 'temp_vfg3k7js3f.jpg', 'test_11', 'images', 0, NULL),
(49, '5', 'temp_sj7ok3onls.jpg', 'test_11', 'images', 0, NULL),
(50, '5', 'temp_f587h97hv.jpg', 'test_11', 'images', 0, NULL),
(52, '5', 'temp_txro353w6w.jpg', 'test_11', 'images', 0, NULL),
(53, '5', 'temp_lx8i7orn6n.jpg', 'test_11', 'images', 0, NULL),
(54, '5', 'temp_zlctez6n64.jpg', 'test_11', 'images', 0, NULL),
(55, '5', 'temp_d4tldmhrz8.jpg', 'test_11', 'images', 0, NULL),
(56, '5', 'temp_kbqdxyzrg.jpg', 'test_11', 'images', 0, NULL),
(57, '5', 'temp_jloy38ttzv.jpg', 'test_11', 'images', 0, NULL),
(58, '5', 'temp_eu86df.jpg', 'test_11', 'images', 0, NULL),
(59, '5', 'temp_g0np62vg7m.jpg', 'test_11', 'images', 0, NULL),
(60, '5', 'temp_fcxhgj8khs.jpg', 'test_11', 'images', 0, NULL),
(61, '5', 'temp_ksd7lqt2b3.png', 'test_11', 'image', 0, NULL),
(62, '5', 'temp_ug82m9x91e.png', 'test_11', 'image', 0, NULL),
(63, '5', 'temp_fcf16xp6u6.png', 'test_11', 'image', 0, NULL),
(64, '5', '64v2gy5qunwugz.png', 'test_11', 'image', 1, NULL),
(67, '5', 'temp_18u97sfmv3.png', 'test_11', 'images', 1, NULL),
(68, '5', 'temp_ks2m158kzg.png', 'test_11', 'images', 1, NULL),
(72, '5', '729mep55fdutd7.png', 'test_11', 'image', 1, NULL),
(77, '5', 'temp_fptkus9b2j.png', 'test_11', 'image', 1, NULL),
(78, '5', 'temp_civ2v07gng.png', 'test_11', 'image', 1, NULL),
(79, '5', 'temp_tgpoibg3gy.png', 'test_11', 'image', 1, NULL),
(84, '5', 'temp_qo7k1u3sl.png', 'test_11', 'image2', 1, NULL),
(85, '5', 'temp_3fbw7whrhh.png', 'test_11', 'image2', 1, NULL),
(86, '5', 'temp_compcuxxks.png', 'test_11', 'image2', 1, NULL),
(87, '5', 'temp_qrfxfm7ejx.png', 'test_11', 'gallery', 1, NULL),
(88, '5', 'temp_npkt3pgv7q.png', 'test_11', 'gallery', 1, NULL),
(89, '5', 'temp_9jg4of7gq8.png', 'test_11', 'gallery', 1, NULL),
(90, '5', 'temp_shcr25iwy.png', 'test_11', 'gallery', 1, NULL),
(91, '5', 'temp_lvkqtnmdj.png', 'test_11', 'gallery', 1, NULL),
(92, '5', 'temp_c6dqn0fzu4.png', 'test_11', 'gallery', 1, NULL),
(93, '5', 'temp_lhrlizs09o.png', 'test_11', 'gallery', 1, NULL),
(94, '5', 'temp_76l9crokg7.png', 'test_11', 'gallery', 1, NULL),
(95, '5', 'temp_u4ijo1ec.png', 'test_11', 'gallery', 1, NULL),
(96, '5', 'temp_k4esr7bhh0.png', 'test_11', 'gallery', 1, NULL),
(97, '5', 'temp_66fndvt91.png', 'test_11', 'gallery', 1, NULL),
(98, '5', 'temp_ecgfctpxf1.png', 'test_11', 'gallery', 1, NULL),
(99, '5', 'temp_vtq3v9dkzy.png', 'test_11', 'gallery', 1, NULL),
(100, '5', 'temp_qrtm85hikl.png', 'test_11', 'gallery', 1, NULL),
(101, '5', 'temp_jb9n5010s3.png', 'test_11', 'gallery', 1, NULL),
(102, '5', 'temp_e8oj0sy3pr.png', 'test_11', 'gallery', 1, NULL),
(103, '5', 'temp_96vp5i9.png', 'test_11', 'gallery', 1, NULL),
(104, '5', 'temp_kjm7whcspg.png', 'test_11', 'gallery', 1, NULL),
(105, '5', 'temp_xnxrkblxpu.png', 'test_11', 'gallery', 1, NULL),
(106, '5', 'temp_hj7k1nvx8i.png', 'test_11', 'gallery', 1, NULL),
(107, '5', 'temp_kdj6gr190f.png', 'test_11', 'gallery', 1, NULL),
(108, '5', 'temp_4s87phzfdc.png', 'test_11', 'gallery', 1, NULL),
(109, '5', 'temp_vy11j55j9s.png', 'test_11', 'gallery', 1, NULL),
(110, '5', 'temp_ojn651hhv.png', 'test_11', 'gallery', 1, NULL),
(111, '5', 'temp_o6vzq6pi1w.png', 'test_11', 'gallery', 1, NULL),
(112, '5', 'temp_l0up4pf3.png', 'test_11', 'gallery', 1, NULL),
(113, '5', 'temp_ktgtx6z5uv.png', 'test_11', 'gallery', 1, NULL),
(114, '5', 'temp_dd7s5nloh1.png', 'test_11', 'gallery', 1, NULL),
(115, '5', 'temp_mysvctx0cy.png', 'test_11', 'gallery', 1, NULL),
(116, '5', 'temp_lplgv3h2jh.png', 'test_11', 'gallery', 1, NULL),
(117, '5', 'temp_ttlkb5he9r.png', 'test_11', 'gallery', 1, NULL),
(118, '5', 'temp_7l9679j3ew.png', 'test_11', 'gallery', 1, NULL),
(119, '5', 'temp_xvcpkfz973.png', 'test_11', 'gallery', 1, NULL),
(120, '5', 'temp_k1nocqh7lm.png', 'test_11', 'gallery', 1, NULL),
(121, '5', 'temp_usyz3esyrr.png', 'test_11', 'gallery', 1, NULL),
(122, '5', 'temp_6wi7odyd6o.png', 'test_11', 'gallery', 1, NULL),
(123, '5', 'temp_b7ieht5juo.png', 'test_11', 'gallery', 1, NULL),
(124, '5', 'temp_80uv1fgz8d.png', 'test_11', 'gallery', 1, NULL),
(125, '5', 'temp_743xys0f7.png', 'test_11', 'gallery', 1, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `site_storages_info`
--

CREATE TABLE IF NOT EXISTS `site_storages_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `path` text,
  `name` text,
  `settings` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `site_storages_info`
--

INSERT INTO `site_storages_info` (`id`, `path`, `name`, `settings`) VALUES
(1, '/storage/users/icons/', 'Иконки для пользователей бэк-офиса', '|images|maxsize=10240|imgw=60|imgwtype=1|imgh=60|imghtype=1|exts=jpg,gif,jpeg|'),
(2, '/storage/site/images/', 'Изображения сайта (общее)', '|images|maxsize=10240|exts=jpg,gif,jpeg,png|'),
(3, '/storage/site/files/', 'Файлы сайта (общее)', '|maxsize=10240|'),
(4, '/storage/site/pdf/', 'Файлы сайта (общее)', '|maxsize=10240|exts=pdf|'),
(5, '/storage/site/images/', 'Баннеры', '|images|maxsize=10240|exts=jpg,gif,jpeg,png,swf|'),
(6, '/storage/site/banners/', 'Баннеры', '|maxsize=10240|exts=jpg,gif,jpeg,png,swf|'),
(7, '/storage/site/images/smallicons/', 'Иконки проектов', '|images|maxsize=10240|exts=jpg,gif,jpeg|');
