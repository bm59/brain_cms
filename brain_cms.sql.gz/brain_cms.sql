-- phpMyAdmin SQL Dump
-- version 3.3.10
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Июн 23 2015 г., 15:40
-- Версия сервера: 5.5.11
-- Версия PHP: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `brain_cms`
--

-- --------------------------------------------------------

--
-- Структура таблицы `pr_banners_clicks`
--

CREATE TABLE IF NOT EXISTS `pr_banners_clicks` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `section_id` bigint(20) NOT NULL,
  `banner_id` bigint(20) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `num` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`banner_id`),
  KEY `date` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `pr_banners_clicks`
--


-- --------------------------------------------------------

--
-- Структура таблицы `pr_banners_shows`
--

CREATE TABLE IF NOT EXISTS `pr_banners_shows` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `section_id` bigint(20) NOT NULL,
  `banner_id` bigint(20) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `num` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`banner_id`),
  KEY `date` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `pr_banners_shows`
--


-- --------------------------------------------------------

--
-- Структура таблицы `site_bk_users_info`
--

CREATE TABLE IF NOT EXISTS `site_bk_users_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `regdate` date DEFAULT NULL,
  `login` varchar(255) DEFAULT NULL,
  `pswd` varchar(255) DEFAULT NULL,
  `type` bigint(20) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `secondname` varchar(255) DEFAULT NULL,
  `parentname` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `picture` bigint(20) DEFAULT NULL,
  `settings` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `site_bk_users_info`
--

INSERT INTO `site_bk_users_info` (`id`, `regdate`, `login`, `pswd`, `type`, `firstname`, `secondname`, `parentname`, `email`, `picture`, `settings`) VALUES
(1, '2011-05-25', 'admin', '21232f297a57a5a743894a0e4a801fc3', 1, 'admin', 'admin', 'admin', '', 0, '|engage|notypechange|norename|nologinchange|undeletable|noswitch|help=users_mainadmin|lasttime=1435051866|'),
(2, '2015-06-23', 'director', '3d4e992d8d8a7d848724aa26ed7f4176', 2, 'director', 'director', 'director', '', 0, '|lasttime=1435055851|engage|'),
(3, '2015-06-23', 'user', 'ee11cbb19052e40b07aac0ca060c23ee', 3, 'user', 'user', 'user', '', 0, '|engage|');

-- --------------------------------------------------------

--
-- Структура таблицы `site_bk_users_types`
--

CREATE TABLE IF NOT EXISTS `site_bk_users_types` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `access` text,
  `settings` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `site_bk_users_types`
--

INSERT INTO `site_bk_users_types` (`id`, `name`, `access`, `settings`) VALUES
(1, 'Разработчики', '', '|undeletable|superaccess|noedit|help=usergroups_admins|'),
(2, 'Администраторы', '|3=|5=view|4=onoff,view,edit|1=|2=view,add,edit,delete|6=|7=|8=|', NULL),
(3, 'Пользователи', '|6=|7=|8=|9=|10=|11=|13=|', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `site_logs`
--

CREATE TABLE IF NOT EXISTS `site_logs` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` datetime DEFAULT NULL,
  `sectionname` varchar(255) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `section_id` varchar(255) DEFAULT NULL,
  `href` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=15 ;

--
-- Дамп данных таблицы `site_logs`
--

INSERT INTO `site_logs` (`id`, `date`, `sectionname`, `comment`, `user_id`, `section_id`, `href`) VALUES
(1, '2015-02-27 08:55:40', 'О нас', 'Изменена страница', '1', '7', '/sitecontent/о_нас/'),
(2, '2015-02-27 17:48:46', 'Текст на главную', 'Изменена страница', '1', '11', '/sitecontent/main_text/'),
(3, '2015-02-27 18:14:04', 'Текст на главную', 'Изменена страница', '1', '11', '/sitecontent/main_text/'),
(4, '2015-02-27 19:31:50', 'Текст на главную', 'Изменена страница', '1', '11', '/sitecontent/main_text/'),
(5, '2015-03-19 10:31:02', 'Контакты', 'Изменена страница', '1', '7', '/sitecontent/contacts/'),
(6, '2015-03-19 11:17:52', 'Контакты', 'Изменена страница', '1', '7', '/sitecontent/contacts/'),
(7, '2015-03-19 11:18:29', 'Контакты', 'Изменена страница', '1', '7', '/sitecontent/contacts/'),
(8, '2015-03-19 11:21:03', 'Контакты', 'Изменена страница', '1', '7', '/sitecontent/contacts/'),
(9, '2015-03-19 11:25:09', 'Цены', 'Изменена страница', '1', '8', '/sitecontent/price/'),
(10, '2015-03-19 11:25:43', 'Цены', 'Изменена страница', '1', '8', '/sitecontent/price/'),
(11, '2015-03-19 11:26:54', 'Цены', 'Изменена страница', '1', '8', '/sitecontent/price/'),
(12, '2015-03-19 15:36:02', 'Контакты', 'Изменена страница', '1', '7', '/sitecontent/contacts/'),
(13, '2015-03-23 11:06:51', 'Текст на главную', 'Изменена страница', '1', '11', '/sitecontent/main_text/'),
(14, '2015-03-23 11:07:39', 'Контакты', 'Изменена страница', '1', '7', '/sitecontent/contacts/');

-- --------------------------------------------------------

--
-- Структура таблицы `site_settings`
--

CREATE TABLE IF NOT EXISTS `site_settings` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `value` text,
  `settings` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `site_settings`
--

INSERT INTO `site_settings` (`id`, `name`, `description`, `value`, `settings`) VALUES
(1, 'pub_page_count', 'Количество элементов на странице типа «Лента»', '20', '|type=integer|notnull|undeletable|'),
(2, 'address', 'Адрес', 'Пермь, Решетникова 4', '|type=string|'),
(3, 'address_comment', 'Комментарий к маркеру на карте', '3-ий этаж, офис 304', '|type=string|');

-- --------------------------------------------------------

--
-- Структура таблицы `site_site_data_sets`
--

CREATE TABLE IF NOT EXISTS `site_site_data_sets` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `settings` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `site_site_data_sets`
--

INSERT INTO `site_site_data_sets` (`id`, `description`, `name`, `settings`) VALUES
(1, 'Лист (1 колонка)', 'sheet1', ''),
(2, 'Справочник', 'spr', ''),
(3, 'Публикация', 'publication', ''),
(4, 'Список с картинками расширенный', 'imagelistext', ''),
(5, 'Справочник расширенный', 'sprext', '');

-- --------------------------------------------------------

--
-- Структура таблицы `site_site_data_types`
--

CREATE TABLE IF NOT EXISTS `site_site_data_types` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `dataset` bigint(20) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `precedence` bigint(20) DEFAULT NULL,
  `settings` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=25 ;

--
-- Дамп данных таблицы `site_site_data_types`
--

INSERT INTO `site_site_data_types` (`id`, `dataset`, `description`, `name`, `type`, `precedence`, `settings`) VALUES
(1, 1, 'Текст', 'text', 'CDTextEditor', 0, '|important|texttype=full|'),
(2, 2, 'Заголовок', 'header', 'CDText', 0, '|important|'),
(3, 2, 'Описание', 'description', 'CDText', 1, ''),
(4, 3, 'Дата', 'date', 'CDDate', 0, ''),
(5, 3, 'Заголовок', 'header', 'CDText', 1, '|important|'),
(6, 3, 'Анонс', 'short', 'CDText', 2, '|important|'),
(7, 3, 'Текст', 'text', 'CDTextEditor', 3, '|important|texttype=full|'),
(8, 3, 'Теги, разделитель -"|"', 'tags', 'CDText', 4, ''),
(9, 4, 'Наименование', 'name', 'CDText', 0, ''),
(10, 4, 'Изображение (280x300)', 'image', 'CDImage', 1, ''),
(11, 4, 'Описание', 'descr', 'CDTextEditor', 2, '|texttype=full|'),
(12, 4, 'Ссылка', 'url', 'CDText', 3, ''),
(13, 4, 'Дополнительная информация', 'dopinfo', 'CDText', 4, ''),
(14, 4, 'Изображение большое', 'big_image', 'CDImage', 1, ''),
(15, 5, 'Наименование', 'name', 'CDText', 0, '|important=1|'),
(16, 5, 'Доп 1', 'dop1', 'CDText', 1, ''),
(17, 5, 'Доп 2', 'dop2', 'CDText', 2, ''),
(18, 5, 'Доп 3', 'dop3', 'CDText', 3, ''),
(19, 5, 'Краткое описание', 'short', 'CDTextArea', 4, ''),
(20, 5, 'Описание', 'text', 'CDTextEditor', 5, '|texttype=full|'),
(21, 5, 'Псеводоним ссылки', 'pseudolink', 'CDText', 6, ''),
(22, 5, 'Title страницы', 'ptitle', 'CDText', 7, ''),
(23, 5, 'Description страницы', 'pdescription', 'CDText', 8, ''),
(24, 5, 'Картинка', 'image', 'CDImage', 9, '');

-- --------------------------------------------------------

--
-- Структура таблицы `site_site_pimagelistext_imagelistext_10`
--

CREATE TABLE IF NOT EXISTS `site_site_pimagelistext_imagelistext_10` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `show` int(1) DEFAULT NULL,
  `show_main` int(1) DEFAULT NULL,
  `precedence` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `image` bigint(20) DEFAULT NULL,
  `descr` text,
  `url` varchar(255) DEFAULT NULL,
  `dopinfo` varchar(255) DEFAULT NULL,
  `big_image` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=14 ;

--
-- Дамп данных таблицы `site_site_pimagelistext_imagelistext_10`
--

INSERT INTO `site_site_pimagelistext_imagelistext_10` (`id`, `show`, `show_main`, `precedence`, `name`, `image`, `descr`, `url`, `dopinfo`, `big_image`) VALUES
(2, 1, 0, 0, 'Автосуши', 6, '', '', '&lt;b&gt;Автосуши&lt;/b&gt;: дизайн сайта и логотипа, разработка и продвижение сайта', 25),
(3, 1, 0, 1, 'Газпром', 9, '', '', '&lt;b&gt;Кургурский филиал \\&quot;Газпром\\&quot;&lt;/b&gt;: дизайн и разработка сайта, стилизация логотипа', 26),
(4, 1, 0, 2, 'Rperm.ru', 10, '', '', '&lt;b&gt;Rperm.ru&lt;/b&gt;: дизайн сайта и логотипа, разработка сайта', 27),
(5, 1, 0, 3, 'Евразийская интеграция', 11, '', '', '&lt;b&gt;Международный форум \\&quot;Евразийская интеграция\\&quot;&lt;/b&gt;: дизайн и разработка сайта', 28),
(6, 1, 0, 4, 'Спешилов', 15, '', '', '&lt;b&gt;Торгово развлекательный комплекс \\&quot;Спешилов\\&quot;&lt;/b&gt;: дизайн и разработка сайта', 29),
(7, 1, 0, 5, 'Новация', 14, '', '', '&lt;b&gt;Производственная фирма \\&quot;Новация\\&quot;&lt;/b&gt;: дизайн и разработка сайта, стилизация логотипа', 39),
(8, 1, 0, 6, 'Live', 16, '', '', '&lt;b&gt;Дизайн студия \\&quot;Live\\&quot;&lt;/b&gt;: дизайн сайта и логотипа, разработка сайта', 31),
(9, 1, 0, 7, 'Мебельная страна', 17, '', '', '&lt;b&gt;Региональный сайт \\&quot;Мебельная страна\\&quot;&lt;/b&gt;: дизайн сайта и логотипа, разработка сайта', 32),
(10, 1, 0, 8, 'Север Транс', 18, '', '', '&lt;b&gt;ООО \\&quot;Север-транс\\&quot;&lt;/b&gt;: дизайн сайта и логотипа, разработка сайта', 33),
(11, 1, 0, 9, 'Территория', 20, '', '', '&lt;b&gt;Газета \\&quot;Территория Пермь\\&quot;&lt;/b&gt;: дизайн сайта и логотипа, разработка сайта', 34),
(12, 1, 0, 11, 'АКСУ', 21, '', '', '&lt;b&gt;АКСУ&lt;/b&gt;: дизайн сайта и логотипа', 35),
(13, 1, 0, 10, 'Логотипы', 37, '', '', '&lt;b&gt;Логотипы&lt;/b&gt;', 38);

-- --------------------------------------------------------

--
-- Структура таблицы `site_site_psheet1_sheet1`
--

CREATE TABLE IF NOT EXISTS `site_site_psheet1_sheet1` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `section_id` bigint(20) DEFAULT NULL,
  `text` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `site_site_psheet1_sheet1`
--

INSERT INTO `site_site_psheet1_sheet1` (`id`, `section_id`, `text`) VALUES
(1, 7, '<h3><strong>Умные сайты<br /></strong></h3>\r\n<p>Телефон: +7 (342) 204 19 35, +7 (922) 354 19 35<br />Email: <a href="mailto: mail@brain-site.ru">mail@brain-site.ru</a><br />Адрес: Пермь, ул. Решетникова 4 оф. 304</p>'),
(2, 8, '<p>Стоимость сайта зависит от его функционального содержания. Точная стоимость сайта обычно определяется после составления технического задания (подробного описания возможностей сайта).</p>\r\n<p>В таблице представлены наиболее распространенные конфигурации сайтов с ценами. В зависимости от ваших требований, к сайту могут быть добавлены любые дополнительные функции. Для получения бесплатной консультации и определения точной стоимости сайта, вы всегда можете отправить заявку или связаться через онлайн-консультант.</p>'),
(3, 11, '<table style="width: 100%;">\r\n<tbody>\r\n<tr>\r\n<td style="width: 50%; padding: 0 20px;">\r\n<h2>Разработка сайтов в Перми</h2>\r\n<p>Хотите заказать разработку сайта, который будет эффективно привлекать ваших потенциальных клиентов 24 часа в сутки? Мы с радостью поможем вам в этом. Мы предлагаем полный перечень работ по созданию и развитию сайтов, начиная от проектирования и дизайна, заканчивая продвижением и поддержкой. В зависимости от ваших требований, мы можем предложить разработку сайта визитки, лендинг пейдж, сайта-каталога, интернет-магазина, корпоративного сайта, а так же нестандартных интернет-проектов.</p>\r\n<p>Мы разрабатываем сайты, ориентированные на результат и всегда предлагаем несколько вариантов разработки сайтов. Начиная от шаблонных решений, с помощью которых можно получить полностью готовый сайт за 1-2 дня, заканчивая полностью индивидуальными сайтами, дизайн и функционал которых, сделаны исходя из ваших требований.</p>\r\n<p>На нашем сайте вы можете ознакомиться с нашими работами, ценами на услуги, а так же отправить заявку на разработку сайта.</p>\r\n</td>\r\n<td style="width: 50%; padding: 0 20px;">\r\n<h2>Продвижение сайтов в Перми</h2>\r\n<p>Работу над продвижением сайта мы начинаем еще на этапе его создания. Это делается для того, чтобы содержание и структура сайта были наиболее оптимально приспособлены для последующего его продвижения. Если сфера вашей деятельности высококонкурентная, то вряд ли стоит рассчитывать на то, что сайт сам по себе будет занимать первые строки выдачи в поисковых системах. Обычно мы предлагаем использовать сразу 2 варианта продвижения сайта: рекламные кампании(Яндекс.Директ, GoogleAdWords, <a href="mailto:Таргет@Mail.ru">Таргет@Mail.ru</a>) и поисковое продвижение.</p>\r\n<p>Первые результаты работы по поисковому продвижению появляются через несколько недель, работа над новым сайтом может занимать до 6 и более месяцев. Плюс этого метода продвижения сайтов заключается в том, что достигнутые результаты (позиции в поисковых системах) обычно сохраняются на долгое время и позволяют получать клиентов без каких либо затрат.</p>\r\n<p>В отличие от seo-продвижения, рекламные кампании позволяют моментально привлечь клиентов на сайт. При правильной настройке, рекламные кампании себя окупают и оправдывают на все 100%.</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>&nbsp;</p>');

-- --------------------------------------------------------

--
-- Структура таблицы `site_site_psprext_sprext_13`
--

CREATE TABLE IF NOT EXISTS `site_site_psprext_sprext_13` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `show` int(1) DEFAULT NULL,
  `precedence` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `dop1` varchar(255) DEFAULT NULL,
  `dop2` varchar(255) DEFAULT NULL,
  `dop3` varchar(255) DEFAULT NULL,
  `short` text,
  `text` text,
  `pseudolink` varchar(255) DEFAULT NULL,
  `ptitle` varchar(255) DEFAULT NULL,
  `pdescription` varchar(255) DEFAULT NULL,
  `image` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `site_site_psprext_sprext_13`
--

INSERT INTO `site_site_psprext_sprext_13` (`id`, `show`, `precedence`, `name`, `dop1`, `dop2`, `dop3`, `short`, `text`, `pseudolink`, `ptitle`, `pdescription`, `image`) VALUES
(1, 1, 1, 'Продвижение сайтов в Перми', '', '', '', '', '<p>Продвижение сайтов или SEO оптимизация &ndash; работа, направленная на повышение позиций сайта в поисковых системах по определенным запросам пользователей.</p>\r\n<h2><strong>В чем плюсы продвижения сайта в интернете<br /> </strong></h2>\r\n<p>Основным плюсом поискового продвижения сайта, является низкая стоимость привлечения посетителя на сайт. Несмотря на значительные вложения на начальном этапе, это один из самых эффективных и недорогих способов привлечения клиентов на сайт. Во первых, у пользователей интернета больше доверия к естественной поисковой выдаче (результатам поиска), нежели к рекламным блокам. Во вторых, при качественном продвижении, достигнутые результаты (позиции сайта по определенным запросам), а следовательно и постоянный поток посетителей, сохраняются надолго даже после окончания работ.</p>\r\n<h2><strong>Продвижение сайта в Яндексе<br /> </strong></h2>\r\n<p>Яндекс является самой популярной поисковой системой в России, поэтому продвижение сайтов в поиске Яндекса &ndash; это основная задача. В процентом соотношении на 2015 год, доля Яндекса составляет 61,6%, а доля Google 26,3%.</p>\r\n<h2><strong>Результаты продвижения сайта<br /> </strong></h2>\r\n<p>Первые результаты поисковой оптимизации сайтов обычно появляются через 4-8 недель после начала работ. Это связано с особенностями работы поисковых систем. После изменений на сайте, необходимо дождаться, когда эти изменения отразятся в поисковой системе. Если у вас новый сайт, то время на его обновления в поисковой системе (индексация сайта) занимает больше времени, чем индексация &laquo;старых&raquo; сайтов.</p>\r\n<h2><strong>Срок работ по продвижению сайта<br /> </strong></h2>\r\n<p>Обычно на продвижение сайта требуется несколько месяцев. При продвижении сайта с оплатой за результат минимальный срок работ составляет 6 месяцев. Сроки обсуждаются индивидуально по каждому проекту и зависят от того является ли сайт новым, по каким запросам и регионам его нужно продвигать, какая конкуренция по продвигаемым запросам.</p>\r\n<h2><strong>Цены на продвижение сайтов в Перми</strong><strong><br /> </strong></h2>\r\n<p>Мы предлагаем несколько вариантов сотрудничества:</p>\r\n<table class="price_table">\r\n<tbody>\r\n<tr><th class="type_0" style="width: 33%;">\r\n<p>Вариант продвижения</p>\r\n</th><th class="type_1" style="width: 33%;">\r\n<p>Срок</p>\r\n</th><th class="type_4" style="width: 33%;">\r\n<p>Ориентировочная цена</p>\r\n</th></tr>\r\n<tr>\r\n<td class="type_0">\r\n<p>Продвижение с гарантией позиций в поиске</p>\r\n</td>\r\n<td class="type_1">\r\n<p>Срок договора - от 6 месяцев<br /> Гарантия достижения результата</p>\r\n</td>\r\n<td class="type_4">\r\n<p>Ежемесячная абонентская плата от 7&nbsp;500 руб</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td class="type_0">\r\n<p>Продвижение с оплатой за посетителей</p>\r\n</td>\r\n<td class="type_1">\r\n<p>Срок от 6 месяцев</p>\r\n</td>\r\n<td class="type_4">\r\n<p>Оплата за прирост количества привлеченных посетителей из поисковых систем &ndash; от 3 руб. за посетителя</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td class="type_0">\r\n<p>Оптимизация страниц сайта</p>\r\n</td>\r\n<td class="type_1">\r\n<p>Единовременная работа</p>\r\n</td>\r\n<td class="type_4">\r\n<p>от 10&nbsp;000 руб</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>&nbsp;</p>\r\n<p>У каждого варианта сотрудничества есть свои плюсы. При продвижении с гарантией позиций &ndash; вы оплачиваете абонентскую плату на протяжении срока действия договора, если результаты не достигнуты, мы вернем вам деньги пропорционально невыполненным обязательствам.</p>\r\n<p>При продвижении сайта с оплатой за посетителя - сумма оплаты рассчитается ежемесячно и зависит от количества привлеченных посетителей из поисковых систем. При отсутствии результатов, вы ничего не платите.</p>\r\n<p>Услуга &laquo;оптимизация сайта&raquo; подразумевает единовременные работы по оптимизации страниц сайта. Если вы предлагаете уникальную продукцию или у вас мало сайтов-конкурентов, этого бывает вполне достаточно для вывода сайта на первую страницу поиска.</p>\r\n<p>Для более точной оценки стоимости продвижения вы можете отправить заявку на расчет стоимости.</p>', 'prodvizhenie_saitov', 'Продвижение сайтов в Перми', 'Продвижение сайтов в Перми', 0),
(2, 1, 2, 'Разработка сайтов', '', '', '', '', '<p><strong>Этапы сотрудничества по разработке сайтов</strong></p>\r\n<p>Обычно процесс сотрудничества происходит следующим образом:</p>\r\n<ul>\r\n<li>Мы договариваемся о встрече и обсуждаем, какой вам нужен сайт. На этом этапе мы определяем точную стоимость и сроки разработки сайта, составляем техническое задание (описание функционала и дизайна вашего сайта)</li>\r\n<li>Разрабатываем и согласовываем с вами дизайн сайта</li>\r\n<li>Программируем функционал сайта</li>\r\n<li>Согласовываем с вами полученный результат</li>\r\n<li>Наполняем и размещаем сайт в интернете</li>\r\n</ul>\r\n<p>Кроме создания сайта мы так же предлагаем услуги по поддержке сайта и его продвижению.</p>\r\n<p><strong>Сроки разработки сайта</strong></p>\r\n<p>Сроки напрямую зависят от сложности функционала сайта; является ли дизайн сайта индивидуальным или шаблонным; как долго длиться процесс согласования дизайна и тестового варианта сайта. Для сокращения сроков и стоимости мы предлагаем использовать шаблонный дизайн сайта (несколько готовых вариантов дизайна на выбор), это может очень значительно сократить срок создания сайта. Срок <strong>разработки индивидуального дизайна</strong> составляет от 5 до 10 дней, и может продлиться, если дизайн не будет утвержден с первого раза. Программирование сайта составляет от 3 дней, в случае разработки сайта-визитки с шаблонным дизайном.</p>\r\n<p><strong>Что входит в разработку сайта</strong></p>\r\n<p>В наши услуги по созданию сайтов всегда включено:</p>\r\n<ul>\r\n<li>Доменное имя в зоне RU на 1 год (ваш адрес в интернете, например НазваниеКомпании.ru)</li>\r\n<li>Хостинг сайта на 1 год (размещение вашего сайта в интернете)</li>\r\n<li>Система управления сайтом (возможность изменять сайт самостоятельно)</li>\r\n<li>Оптимизация под поисковые системы (улучшения, повышающие позиции сайта в поисковых системах)</li>\r\n<li>Регистрация сайта в поисковых системах (позволяет ускорить появления сайта в поисковых системах)</li>\r\n<li>Счетчик посещаемости (позволяет контролировать посещаемость, источники посетителей и множество других параметров)</li>\r\n<li>Техническая поддержка (консультации в процессе эксплуатации сайта)</li>\r\n</ul>\r\n<p>Кроме того, мы даем гарантию 1 год на выполненные работы, поэтому можете быть уверены, что ваш сайт будет работать.</p>\r\n<p>В разделе &laquo;Цены&raquo; вы можете более подробно ознакомиться с типовыми конфигурациями <strong>ценами на разработку сайтов</strong>.</p>\r\n<p><strong>Работа сайта, привлечение клиентов<br /> </strong></p>\r\n<p>Чтобы после разработки сайта, он действительно работал, т.е. не просто размещался где-то в интернете, а приводил реальных клиентов, нужно чтобы на него заходили целевые посетители (ваши потенциальные клиенты). Рассчитывать на то, что на сайт сразу же повалится поток посетителей сам по себе, не стоит, особенно учитывая то, что и в интернете есть своя конкуренция. Для гарантированного привлечения клиентов на сайт мы предлагаем услуги по комплексному продвижению сайтов, включающее в себя <strong>продвижение в поисковых системах</strong> и <strong>рекламные кампании в интернете</strong>. Каждый из этих способов продвижения обладает своими преимуществами и использование их в комплексе позволяет достигнуть двух основных целей: моментальное привлечение целевых посетителей на сайт и создание постоянного потока посетителей в будущем без финансовых вложений.</p>\r\n<p><em>&nbsp;</em></p>', 'razrabotka_saitov', '', '', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `site_site_sections`
--

CREATE TABLE IF NOT EXISTS `site_site_sections` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `pattern` varchar(255) DEFAULT NULL,
  `parent` bigint(20) DEFAULT NULL,
  `precedence` bigint(20) DEFAULT NULL,
  `isservice` int(1) DEFAULT NULL,
  `keywords` text,
  `title` text,
  `tags` text,
  `description` text,
  `visible` tinyint(6) DEFAULT NULL,
  `settings` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=14 ;

--
-- Дамп данных таблицы `site_site_sections`
--

INSERT INTO `site_site_sections` (`id`, `name`, `path`, `pattern`, `parent`, `precedence`, `isservice`, `keywords`, `title`, `tags`, `description`, `visible`, `settings`) VALUES
(1, 'Управление сайтом', 'control', 'PFolder', 0, -1, 1, '', '', '', '', 1, '|nopathchange|nodestination|undrop|undeletable|enable_actions=view,add,edit,delete|'),
(2, 'Настройки', 'settings', 'PFolder', 1, -1, 1, '', '', '', '', 1, '|nopathchange|nodestination|undrop|undeletable|enable_actions=view,add,edit,delete|'),
(3, 'Доступ', 'access', 'PFolder', 0, -1, 1, '', '', '', '', 1, '|nopathchange|nodestination|undrop|undeletable|enable_actions=view,add,edit,delete|'),
(4, 'Пользователи', 'users', 'PFolder', 3, -1, 1, '', '', '', '', 1, '|nopathchange|nodestination|undrop|undeletable|enable_actions=onoff,view,add,edit,delete|'),
(5, 'Группы', 'groups', 'PFolder', 3, -1, 1, '', '', '', '', 1, '|nopathchange|nodestination|undrop|undeletable|enable_actions=view,add,edit,delete|'),
(6, 'Содержимое сайта', 'sitecontent', 'PFolder', 0, 0, 0, '', 'Разработка сайтов в Перми, продвижение сайтов', '', 'Разработка сайтов в Перми, продвижение сайтов', 0, '|nopathchange|nodestination|undrop|undeletable|enable_actions=view,add,edit,delete|'),
(7, 'Контакты', 'contacts', 'PSheet1', 6, 0, 0, '', 'Контакты', '', 'Контакты', 1, '|nopathchange|nodestination|undrop|undeletable|'),
(8, 'Цены', 'price', 'PSheet1', 6, 1, 0, '', 'Цены', '', 'Цены', 1, '|nopathchange|nodestination|undrop|undeletable|'),
(9, 'Заказать сайт', 'order', 'PSheet1', 6, 2, 0, '', 'Заказать сайт', '', 'Заказать сайт', 1, '|nopathchange|nodestination|undrop|undeletable|'),
(10, 'Портфолио', 'portfolio', 'PImageListExt', 6, 3, 0, '', '', '', '', 1, '|nopathchange|nodestination|undrop|undeletable|'),
(11, 'Текст на главную', 'main_text', 'PSheet1', 6, 4, 0, '', '', '', '', 1, '|nopathchange|nodestination|undrop|undeletable|'),
(13, 'Услуги', 'uslugi', 'PSprExt', 6, 5, 0, '', '', '', '', 1, '|nopathchange|nodestination|undrop|undeletable|');

-- --------------------------------------------------------

--
-- Структура таблицы `site_storages_files`
--

CREATE TABLE IF NOT EXISTS `site_storages_files` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `stid` text,
  `name` varchar(255) DEFAULT NULL,
  `theme` varchar(255) DEFAULT NULL,
  `rubric` varchar(255) DEFAULT NULL,
  `uid` bigint(20) DEFAULT NULL,
  `settings` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=41 ;

--
-- Дамп данных таблицы `site_storages_files`
--

INSERT INTO `site_storages_files` (`id`, `stid`, `name`, `theme`, `rubric`, `uid`, `settings`) VALUES
(6, '2', '6s6vhokuhwcwy.png', 'imagelistext_10', 'image', 2, NULL),
(9, '2', '9upi1is4u4pqf.png', 'imagelistext_10', 'image', 3, NULL),
(10, '2', '10p4ium0ne7rid.png', 'imagelistext_10', 'image', 4, NULL),
(11, '2', '11qhh672ugohwv.png', 'imagelistext_10', 'image', 5, NULL),
(14, '2', '14xrwv6jcl9u8.png', 'imagelistext_10', 'image', 7, NULL),
(15, '2', '15drn49i60lr5.png', 'imagelistext_10', 'image', 6, NULL),
(17, '2', '171lmchg9n1w7x.png', 'imagelistext_10', 'image', 9, NULL),
(18, '2', '18xox25d31pp4e.png', 'imagelistext_10', 'image', 10, NULL),
(20, '2', '20ll616xg3ojc.png', 'imagelistext_10', 'image', 11, NULL),
(21, '2', '215tr3q3ojrukx.png', 'imagelistext_10', 'image', 12, NULL),
(25, '2', 'temp_fcmqsm57u3.png', 'imagelistext_10', 'big_image', 2, NULL),
(26, '2', 'temp_cl8mmi7ktk.png', 'imagelistext_10', 'big_image', 3, NULL),
(27, '2', 'temp_f7ggvdfbw.png', 'imagelistext_10', 'big_image', 4, NULL),
(28, '2', 'temp_m99skz9hfq.png', 'imagelistext_10', 'big_image', 5, NULL),
(29, '2', 'temp_lr82mnn1ip.png', 'imagelistext_10', 'big_image', 6, NULL),
(31, '2', 'temp_q6pwpoz7gg.png', 'imagelistext_10', 'big_image', 8, NULL),
(32, '2', 'temp_ontlhklc8w.png', 'imagelistext_10', 'big_image', 9, NULL),
(33, '2', 'temp_xvc408hj5.png', 'imagelistext_10', 'big_image', 10, NULL),
(34, '2', 'temp_hlbhd2k8y.png', 'imagelistext_10', 'big_image', 11, NULL),
(35, '2', 'temp_zgpdk34yoi.png', 'imagelistext_10', 'big_image', 12, NULL),
(37, '2', '376psrkeyq3k4.png', 'imagelistext_10', 'image', 13, NULL),
(38, '2', 'temp_gun6ip9z7.png', 'imagelistext_10', 'big_image', 13, NULL),
(39, '2', 'temp_jb90ehiyo.png', 'imagelistext_10', 'big_image', 7, NULL),
(40, '2', 'temp_qt6c53iutv.png', 'imagelistext_10', 'image', 8, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `site_storages_info`
--

CREATE TABLE IF NOT EXISTS `site_storages_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `path` text,
  `name` text,
  `settings` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `site_storages_info`
--

INSERT INTO `site_storages_info` (`id`, `path`, `name`, `settings`) VALUES
(1, '/storage/users/icons/', 'Иконки для пользователей бэк-офиса', '|images|maxsize=10240|imgw=60|imgwtype=1|imgh=60|imghtype=1|exts=jpg,gif,jpeg|'),
(2, '/storage/site/images/', 'Изображения сайта (общее)', '|images|maxsize=10240|exts=jpg,gif,jpeg,png|'),
(3, '/storage/site/files/', 'Файлы сайта (общее)', '|maxsize=10240|');
