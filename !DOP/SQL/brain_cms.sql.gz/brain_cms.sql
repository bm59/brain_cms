-- phpMyAdmin SQL Dump
-- version 3.3.10
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Июн 22 2016 г., 08:21
-- Версия сервера: 5.5.11
-- Версия PHP: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `brain_cms`
--

-- --------------------------------------------------------

--
-- Структура таблицы `site_bk_users_info`
--

CREATE TABLE IF NOT EXISTS `site_bk_users_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `regdate` date DEFAULT NULL,
  `login` varchar(255) DEFAULT NULL,
  `pswd` varchar(255) DEFAULT NULL,
  `type` bigint(20) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `secondname` varchar(255) DEFAULT NULL,
  `parentname` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `picture` bigint(20) DEFAULT NULL,
  `settings` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `site_bk_users_info`
--

INSERT INTO `site_bk_users_info` (`id`, `regdate`, `login`, `pswd`, `type`, `firstname`, `secondname`, `parentname`, `email`, `picture`, `settings`) VALUES
(1, '2011-05-25', 'admin', '039a8f73e1e5dcf7663d4ef8db24ece4', 1, 'admin', 'admin', 'admin', '', 0, '|engage|notypechange|norename|nologinchange|undeletable|noswitch|help=users_mainadmin|lasttime=1463642305|'),
(2, '2015-06-23', 'director', '3d4e992d8d8a7d848724aa26ed7f4176', 2, 'director', 'director', 'director', '', 0, '|lasttime=1442854840|engage|'),
(3, '2015-06-25', 'user', 'ee11cbb19052e40b07aac0ca060c23ee', 3, 'user', 'user', 'user', '', 0, '|engage|lasttime=1436707289|');

-- --------------------------------------------------------

--
-- Структура таблицы `site_bk_users_types`
--

CREATE TABLE IF NOT EXISTS `site_bk_users_types` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `access` text,
  `settings` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `site_bk_users_types`
--

INSERT INTO `site_bk_users_types` (`id`, `name`, `access`, `settings`) VALUES
(1, 'Разработчики', '', '|undeletable|superaccess|noedit|help=usergroups_admins|'),
(2, 'Администраторы', '|3=|5=view,add,edit,delete|4=onoff,view,add,edit,delete|1=|2=view,add,edit,delete|7=|6=|66=view,edit,delete|100=view,add,edit|', NULL),
(3, 'Пользователи', '|6=|7=|8=|9=|10=|11=|13=|', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `site_log`
--

CREATE TABLE IF NOT EXISTS `site_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `item_id` bigint(20) NOT NULL,
  `descr` varchar(255) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `changes` text,
  `user_name` varchar(255) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `section_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_num` (`item_id`),
  KEY `descr` (`descr`),
  KEY `date` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `site_log`
--


-- --------------------------------------------------------

--
-- Структура таблицы `site_settings`
--

CREATE TABLE IF NOT EXISTS `site_settings` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `value` text,
  `settings` text,
  `precedence` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=12 ;

--
-- Дамп данных таблицы `site_settings`
--

INSERT INTO `site_settings` (`id`, `name`, `description`, `value`, `settings`, `precedence`) VALUES
(1, 'pub_page_count', 'Количество элементов на странице типа «Лента»', '20', '|type=integer|notnull|undeletable|', 4),
(2, 'address', 'Адрес', '', '|type=string|', 1),
(3, 'address_comment', 'Комментарий к маркеру на карте', '', '|type=string|', 5),
(4, 'counters', 'Счетчики', '', '|type=text|', 6),
(5, 'log_enable', 'Вести лог событий', '1', '|type=int|', 7),
(6, 'pr_doptit', 'Дополнение к title (кроме главной)', 'имя-сайта.ru', '|type=string|', 8),
(8, 'phone', 'Телефон', '', '|type=string|', 2),
(9, 'email', 'Email', '', '|type=string|', 3),
(10, 'admin_logo', 'Логотип для входа в панель', '0', '|type=image|', 9),
(11, 'callback_email', 'email адреса для отправки заказа звонков', '', '|type=string|', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `site_site_data_sets`
--

CREATE TABLE IF NOT EXISTS `site_site_data_sets` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `settings` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `site_site_data_sets`
--


-- --------------------------------------------------------

--
-- Структура таблицы `site_site_data_types`
--

CREATE TABLE IF NOT EXISTS `site_site_data_types` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `dataset` bigint(20) DEFAULT NULL,
  `section_id` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `precedence` bigint(20) DEFAULT NULL,
  `settings` text,
  `setting_style_edit` text,
  `setting_style_search` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `site_site_data_types`
--


-- --------------------------------------------------------

--
-- Структура таблицы `site_site_goods_color`
--

CREATE TABLE IF NOT EXISTS `site_site_goods_color` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `good_id` bigint(20) DEFAULT NULL,
  `precedence` bigint(20) DEFAULT NULL,
  `kol` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `color_code` varchar(255) DEFAULT NULL,
  `color_image` bigint(20) DEFAULT NULL,
  `attach_image` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `site_site_goods_color`
--


-- --------------------------------------------------------

--
-- Структура таблицы `site_site_goods_size`
--

CREATE TABLE IF NOT EXISTS `site_site_goods_size` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `good_id` bigint(20) DEFAULT NULL,
  `kol` bigint(20) DEFAULT NULL,
  `precedence` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `site_site_goods_size`
--


-- --------------------------------------------------------

--
-- Структура таблицы `site_site_order_goods`
--

CREATE TABLE IF NOT EXISTS `site_site_order_goods` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) DEFAULT NULL,
  `good_id` bigint(20) DEFAULT NULL,
  `kol` bigint(20) DEFAULT NULL,
  `price` bigint(20) DEFAULT NULL,
  `summ` bigint(20) DEFAULT NULL,
  `size_id` bigint(20) NOT NULL,
  `color_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `site_site_order_goods`
--


-- --------------------------------------------------------

--
-- Структура таблицы `site_site_order_tmp`
--

CREATE TABLE IF NOT EXISTS `site_site_order_tmp` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `site_site_order_tmp`
--


-- --------------------------------------------------------

--
-- Структура таблицы `site_site_order_tmp_goods`
--

CREATE TABLE IF NOT EXISTS `site_site_order_tmp_goods` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tmp_order_id` bigint(20) DEFAULT NULL,
  `good_id` bigint(20) DEFAULT NULL,
  `kol` bigint(20) DEFAULT NULL,
  `price` bigint(20) DEFAULT NULL,
  `summ` bigint(20) DEFAULT NULL,
  `size_id` bigint(20) NOT NULL,
  `color_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `site_site_order_tmp_goods`
--


-- --------------------------------------------------------

--
-- Структура таблицы `site_site_sections`
--

CREATE TABLE IF NOT EXISTS `site_site_sections` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `pattern` varchar(255) DEFAULT NULL,
  `parent` bigint(20) DEFAULT NULL,
  `precedence` bigint(20) DEFAULT NULL,
  `isservice` int(1) DEFAULT NULL,
  `keywords` text,
  `title` text,
  `tags` text,
  `description` text,
  `header` text,
  `visible` tinyint(6) DEFAULT NULL,
  `settings` text,
  `settings_personal` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `site_site_sections`
--

INSERT INTO `site_site_sections` (`id`, `name`, `path`, `pattern`, `parent`, `precedence`, `isservice`, `keywords`, `title`, `tags`, `description`, `header`, `visible`, `settings`, `settings_personal`) VALUES
(1, 'Управление сайтом', 'control', 'PFolder', 0, -1, 1, '', '', '', '', NULL, 0, '|nopathchange|nodestination|undrop|undeletable|enable_actions=view,add,edit,delete|', NULL),
(2, 'Настройки', 'settings', 'PFolder', 1, -1, 1, '', '', '', '', NULL, 1, '|nopathchange|nodestination|undrop|undeletable|enable_actions=view,add,edit,delete|', NULL),
(3, 'Доступ', 'access', 'PFolder', 0, -1, 1, '', '', '', '', NULL, 1, '|nopathchange|nodestination|undrop|undeletable|enable_actions=view,add,edit,delete|', NULL),
(4, 'Пользователи', 'users', 'PFolder', 3, -1, 1, '', '', '', '', NULL, 1, '|nopathchange|nodestination|undrop|undeletable|enable_actions=onoff,view,add,edit,delete|', NULL),
(5, 'Группы', 'groups', 'PFolder', 3, -1, 1, '', '', '', '', NULL, 1, '|nopathchange|nodestination|undrop|undeletable|enable_actions=view,add,edit,delete|', NULL),
(6, 'Содержимое сайта', 'sitecontent', 'PFolder', 0, 0, 0, '', '', '', '', NULL, 0, '|nopathchange|nodestination|undrop|undeletable|enable_actions=view,add,edit,delete|', NULL),
(7, 'Логи действий', 'log', 'PLog', 1, 0, 1, '', '', '', '', NULL, 1, '|nopathchange|nodestination|undrop|undeletable|', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `site_storages_files`
--

CREATE TABLE IF NOT EXISTS `site_storages_files` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `stid` text,
  `name` varchar(255) DEFAULT NULL,
  `theme` varchar(255) DEFAULT NULL,
  `rubric` varchar(255) DEFAULT NULL,
  `uid` bigint(20) DEFAULT NULL,
  `settings` text,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

--
-- Дамп данных таблицы `site_storages_files`
--


-- --------------------------------------------------------

--
-- Структура таблицы `site_storages_info`
--

CREATE TABLE IF NOT EXISTS `site_storages_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `path` text,
  `name` text,
  `settings` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `site_storages_info`
--

INSERT INTO `site_storages_info` (`id`, `path`, `name`, `settings`) VALUES
(1, '/storage/users/icons/', 'Иконки для пользователей бэк-офиса', '|images|maxsize=10240|imgw=60|imgwtype=1|imgh=60|imghtype=1|exts=jpg,gif,jpeg|'),
(2, '/storage/site/images/', 'Изображения сайта (общее)', '|images|maxsize=10240|exts=jpg,gif,jpeg,png|'),
(3, '/storage/site/files/', 'Файлы сайта (общее)', '|maxsize=10240|'),
(4, '/storage/storage/site/images/', 'Изображения сайта (общее)', '|maxsize=10240|exts=jpg,gif,jpeg,png,swf|'),
(5, '/storage/site/banners/', 'Баннеры', '|images|maxsize=10240|exts=swf,jpg,gif,jpeg,png|');
