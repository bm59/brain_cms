<?
//*************************
//Permissions configuration
//******************
// $delete_files=true;
// $create_folders=true;
// $delete_folders=true;
// $upload_files=true;
// $rename_files=true;
// $rename_folders=true;
// $duplicate_files=true;

//***************************************************
//Specific file or directory operations blocking
//***************************************************
// $tmpFlieName = '(filename)';
// $filePermissions[$tmpFlieName] = 
//     array(
//         'prevent_duplicate' => true,
//         'prevent_rename' => true,
//         'prevent_delete' => true
//     );

// $tmpFlieName = '(dirname)';
// $filePermissions[$tmpFlieName] = 
//     array(
//         'prevent_rename' => true,
//         'prevent_delete' => true
//     );

