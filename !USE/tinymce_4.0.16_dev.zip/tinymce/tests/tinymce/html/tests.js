{
	"title": "tinymce.html",
	"tests": [
		{"title": "DomParser", "url": "DomParser.html"},
		{"title": "Entities", "url": "Entities.html"},
		{"title": "Node", "url": "Node.html"},
		{"title": "SaxParser", "url": "SaxParser.html"},
		{"title": "Schema", "url": "Schema.html"},
		{"title": "Serializer", "url": "Serializer.html"},
		{"title": "Styles", "url": "Styles.html"},
		{"title": "Writer", "url": "Writer.html"}
	]
}
